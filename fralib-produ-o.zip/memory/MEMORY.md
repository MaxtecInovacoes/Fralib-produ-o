# Memory Index — FraLib

## Recorrente / Arquitetura
- [Dominio FraLib](dominio-fralib.md) — `seunegociofralib.site` é o canonico, NAO `fralib.com.br`
- [Deploy VPS Nginx](deploy-vps-nginx.md) — VPS tem 2 diretorios; hook NAO copia tudo sozinho
- [Hook corrompe arquivos](hook-local-corrompe-arquivos.md) — hook local corrompe em-dashes/docstrings

## Pipeline / Agentes
- [Audit Completo 2026-07-10](AUDITORIA_COMPLETA_FRALIB_2026-07-10.md) — 91 arquivos, código morto, bugs runtime
- [Esteira Viva Religada](esteira-viva-religada.md) — worker dispatcher unificado, loop de inventário fecha

## Franz (SDR)
- [Franz v2 Memoria](franz-v2-memoria-aprendizado-audio.md) — FranzMemory/FranzLearning/Whisper
- [Franz 15 Angulos](franz-15-angulos-conversao.md) — 15 ângulos SDR enterprise
- [SDR Sem Fallbacks](feedback_sdr_no_fallbacks.md) — SDR NUNCA usa fallback genérico

## Design System / Builder
- [Morte dos Clones](morte-dos-clones-paleta-unica.md) — paleta única por hash SHA-256 do nome
- [Design Pole Caminho Vivo](design-pole-caminho-vivo.md) — design-system-tokens.css (BOLD)
- [Massa Corporal Manifesto](massa-corporal-manifesto.md) — Builder garante ≥5 dobras (Manifesto+Metodologia); JSON-LD não mente horário

## Qualidade / QA
- [Quality Gate Cinematografico](quality-gate-cinematografico.md) — reprova azul default / clone / ficção
- [OpenUI Rating Hallucination](openui-rating-hallucination-fix.md) — LLM não inventa ratings

## Bugs conhecidos
- [Franz Defer Loop Bug](franz-defer-loop-bug.md) — loop fora janela 8-21h
- [Franz CoT Vazamento](franz-cot-vazamento-9router.md) — CoT vaza via 9router/DeepSeek
- [Bugs Pipeline Jina Playwright](bugs-pipeline-jina-playwright-2026-07.md) — NameError + Playwright sync
