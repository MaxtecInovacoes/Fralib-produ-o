# MEMORY — FraLib

Notas rápidas. Skills completos em `.claude/skills/`.

## One-liners

### Score Caio (smoke legacy espera ≥90)
```python
from backend.agents.caio.agent import _calcular_score
score, _ = _calcular_score({'rating':5,'reviews':500,'possui_site':False,'fotos':8})
# Esperado: 90 (rating 5=+35, reviews 500=+35, sem site=+20, fotos=+10, cidade=+5)
```

### Manager E2E
```python
from backend.agents.manager.agent import run_pipeline, PipelineState
state = PipelineState(tenant_id=1, segmento="academia", cidade="Curitiba",
                      lead_data={"nome":"X","cidade":"Curitiba","segmento":"academia",
                                 "telefone":"11999887766","rating":4.5,"reviews_count":50})
print(run_pipeline(state).current_state)  # esperado: "done"
```

### Git push com bypass de v1.1 protection
```bash
SKIP_V11_PROTECTION=1 git add -A
SKIP_V11_PROTECTION=1 git commit -m "..."
```

### Backup antes de mudanças grandes
```bash
TS=$(date +%Y%m%d_%H%M%S)
mkdir -p backups/pre-removal-$TS
tar -czf backups/pre-removal-$TS/full.tar.gz backend/ server.py worker.py pipeline.py
```

## VPS

- SSH: `ssh root@100.101.18.1`
- Deploy: `git push origin master` → `scripts/post-receive` na VPS
- Services: `systemctl status fralib-api fralib-worker fralib-franz fralib-wpp-listener fralib-hermes`
- Portas: API :8000, Whatsmeow :3001, Postgres :5433
- Health: `curl https://fralib.com/health`

## Stack pinning

- LangGraph **NÃO funciona** nesta máquina (langchain-core incompatível). **Usar FSM pura**.
- Playwright já está instalado. Não precisa instalar.
- DuckDuckGo (`duckduckgo-search`) e `httpx` estão disponíveis.

## Comandos úteis

```bash
# Limpar cache e logs
rm -rf backend/__pycache__ backend/agents/__pycache__

# Reset locks órfãos (Postgres)
python pipeline.py smoke --dry-run --fix-locks  # (não implementado ainda)

# Ver tamanho do projeto
du -sh C:/fralib/

# Listar rotas do server
python -c "from server import app; print('\n'.join(sorted([f'{r.methods} {r.path}' for r in app.routes if hasattr(r, 'methods')])))"
```

## Status atual (2026-07-14)

- ✅ 10 agentes novos em produção
- ✅ 48/48 tests agents passam
- ✅ Smoke 9/11 (frontend-canonical + phase6-contracts pré-existentes)
- ⚠️ Server só tem 5 rotas (endpoints legados não reativados — falta infra)
- ⚠️ Frontend não comunica com backend (auth/billing endpoints faltam)
