# FraLib — VPS Setup Guide

Guia pra ativar o sistema em produção na VPS (`seunegociofralib.site`).

## Conexão VPS

```bash
ssh fralib
# (config em ~/.ssh/config: Host fralib -> 187.77.37.72)
```

## Setup one-shot (após `git pull`)

```bash
cd /root/fralib

# 1. Venv + deps
python3 -m venv .venv
.venv/bin/pip install duckduckgo-search httpx pydantic

# 2. Pipeline permanente
bash scripts/setup_pipeline_vps.sh

# 3. Verificar
systemctl status fralib-pipeline.service
tail -f /var/log/fralib-pipeline.log
```

## O que o pipeline faz (a cada 1h)

Varre **4 segmentos × 5 cidades = 20 combinações**:
- Segmentos: academia, barbearia, restaurante, clinica
- Cidades: Curitiba, São Paulo, Rio de Janeiro, Belo Horizonte, Porto Alegre

Para cada combinação:
1. **Hunter** busca no Overpass (OpenStreetMap, grátis)
2. **Caio** qualifica o lead
3. **Manager** roda 10 fases
4. **Builder** gera HTML (Tailwind + Schema)
5. **Quality Gate** valida (≥50% passa)
6. **Deploy** em `/var/www/fralib/sites/<tenant>/<slug>/`
7. **Log** em `/var/www/fralib/pipeline_log.jsonl`

**Resultado**: até 20 sites/dia publicados automaticamente.

## URLs públicas geradas

```
https://seunegociofralib.site/sites/<tenant_id>/<slug>-<lead_id>/
```

Exemplos reais:
- https://seunegociofralib.site/sites/1/academia-full-fitness-lead-232/
- https://seunegociofralib.site/sites/1/contours-express-lead-116/
- https://seunegociofralib.site/sites/2/pablo-corretor-de-imoveis/

## Estrutura de cada site deployado

```
/var/www/fralib/sites/<tenant_id>/<slug>-<lead_id>/
├── index.html       (HTML Tailwind + Schema LocalBusiness + WhatsApp CTA)
└── metadata.json    (tenant_id, lead_id, lead_name, cidade, segmento,
                       quality_score, variacao, deployed_at, size_bytes)
```

## Comandos úteis

```bash
# Status
systemctl status fralib-pipeline.service

# Logs ao vivo
tail -f /var/log/fralib-pipeline.log

# Ver sites deployados
ls -la /var/www/fralib/sites/1/ /var/www/fralib/sites/2/

# Reiniciar pipeline
systemctl restart fralib-pipeline.service

# Parar pipeline (sem desinstalar)
systemctl stop fralib-pipeline.service

# Rodar 1 vez só (teste)
.venv/bin/python -m backend.agents.manager.production_loop \
    --sites-root /var/www/fralib/sites \
    --once \
    --segmentos academia \
    --cidades "Curitiba"
```

## Validar acesso público

```bash
curl -s -o /dev/null -w 'HTTP %{http_code} | %{size_download}B | %{time_total}s\n' \
  https://seunegociofralib.site/sites/1/academia-full-fitness-lead-232/
```

Resultado esperado:
```
HTTP 200 | 3645B | 0.094s
```

## Troubleshooting

| Sintoma | Causa | Fix |
|---|---|---|
| Service em "activating" e sai | Python/venv errado | Ver `ExecStart` no .service, criar `.venv` |
| Sites com 0 leads | Overpass API down | Ver `/var/log/fralib-pipeline.log` |
| Hunter timeout | Sem rede | `ssh fralib "curl https://overpass-api.de/api/interpreter"` |
| Nginx 404 | Pasta `sites/` não existe | `mkdir -p /var/www/fralib/sites` |
| Lead com telefone None | OSM sem telefone | Caio rejeita (FRIO score baixo) — normal |

## Performance observado

- 1 site completo: ~3-5 segundos
- 20 combinações/hora: ~60-100s total (não bloqueia)
- Disco por site: ~3.6 KB HTML + 0.5 KB metadata
- Memória Python: ~30 MB estável
- CPU idle: <1%

## Custos

- **LLM (Claude Sonnet)**: ~$0.10-0.30 por site
- **Hosting (VPS)**: incluído no contrato atual
- **Domínio seunegociofralib.site**: existente
- **Overpass API**: grátis
- **Total por site**: ~$0.10-0.30

Com 20 sites/dia = ~$2-6/dia = ~$60-180/mês.

## Próximos passos

1. **WhatsApp real** — conectar Franz ao whatsmeow daemon
2. **Mais nichos** — adicionar "veterinária", "pet shop", "oficina mecânica", etc
3. **Mais cidades** — começar com capitais do Brasil
4. **Hunter otimizado** — adicionar cache local para evitar chamadas repetidas