# Sistema de Pedidos de Leads — Mapa de Referência

> Última atualização: 2026-07-28
> Implementação: commits pendentes (não feito push ainda)

---

## 1. Problema resolvido

O Hunter anterior rodava como scraper contínuo com meta global de estoque. O usuário não tinha controle sobre:
- Quantos leads quer por pedido
- Quando o Hunter deve parar (atingir meta)
- Agendamento automático (cron diário/semanal)
- Visibilidade do progresso X/Y por pedido

**Solução:** Sistema de pedidos com quota (`lead_requests`) onde cada pedido tem meta própria, contador de entrega, modo manual/cron, e auto-pausa ao atingir a quantidade_total.

---

## 2. Arquivos criados/modificados

### Novos
| Arquivo | Função |
|---------|--------|
| `backend/services/lead_request_service.py` | CRUD service para tabela `lead_requests` |
| `backend/endpoints/lead_request_endpoints.py` | 7 endpoints REST |
| `docs/lead-request-system-map.html` | Este documento visual |

### Modificados
| Arquivo | Mudança |
|---------|---------|
| `backend/services/lead_supply_engine.py` | (a) `ensure_schema()` — cria tabela `lead_requests` + índices. (b) `handle_pipeline_job_finished()` — hook que incrementa `quantidade_entregue` após site deployado + auto-conclui pedido se atingiu meta |
| `backend/endpoints/__init__.py` | Exporta `lead_request_router` |
| `server.py` | Adiciona `"backend.endpoints.lead_request_endpoints"` em `_ESSENTIAL_ROUTERS` |
| `frontend/admin.html` | (a) Painel "Meus Pedidos" (`#painel-pedidos`). (b) Modal "Novo Pedido" (`#modalNovoPedido`). (c) Funções JS: `abrirModalNovoPedido`, `criarNovoPedido`, `carregarPedidos`, `iniciarPedido`, `pausarPedido`, `cancelarPedido` |

---

## 3. Schema — tabela `lead_requests`

```sql
CREATE TABLE IF NOT EXISTS lead_requests (
    id SERIAL PRIMARY KEY,
    tenant_id INTEGER NOT NULL,
    nicho TEXT NOT NULL,
    cidade TEXT NOT NULL,
    score_min INTEGER NOT NULL DEFAULT 45,
    quantidade_total INTEGER NOT NULL,          -- meta (ex: 10 sites)
    quantidade_entregue INTEGER NOT NULL DEFAULT 0,  -- contador (só incrementa APÓS deploy)
    quantidade_por_execucao INTEGER NOT NULL DEFAULT 10,  -- leads por rodada do Hunter
    status VARCHAR(20) NOT NULL DEFAULT 'enfileirado',
        -- enfileirado | executando | pausado | concluido | cancelado
    modo VARCHAR(10) NOT NULL DEFAULT 'manual',  -- manual | cron
    cron_schedule VARCHAR(50),                   -- ex: "0 8 * * *"
    proxima_execucao TIMESTAMP,                  -- para modo=cron
    erro TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_lead_requests_tenant_status ON lead_requests (tenant_id, status);
CREATE INDEX idx_lead_requests_proxima ON lead_requests (proxima_execucao)
    WHERE status IN ('enfileirado', 'executando');
```

**Campos-chave:**
- `quantidade_entregue` — incrementado por `increment_delivered()` em `lead_request_service.py`, chamado por `handle_pipeline_job_finished()` (lead_supply_engine.py) APÓS deploy confirmado
- `status` — transições: `enfileirado` → `executando` → `pausado`/`concluido`/`cancelado`
- `modo` + `cron_schedule` + `proxima_execucao` — controle de agendamento automático

---

## 4. Endpoints

| Método | Path | Auth | Descrição |
|--------|------|------|-----------|
| POST | `/api/lead-request` | ✅ | Cria pedido (nicho, cidade, qtd_total, score_min, qtd_exec, modo, cron_schedule) |
| GET | `/api/lead-request` | ✅ | Lista pedidos do tenant |
| GET | `/api/lead-request/{id}` | ✅ | Detalhe de um pedido |
| POST | `/api/lead-request/{id}/start` | ✅ | Inicia (enfileirado→executando) ou retoma (pausado→executando) |
| POST | `/api/lead-request/{id}/pause` | ✅ | Pausa (executando���pausado) |
| POST | `/api/lead-request/{id}/cancel` | ✅ | Cancela definitivamente |
| POST | `/api/lead-request/cron/tick` | ✅ | Worker-cron: processa pedidos cron com `proxima_execucao <= now` |

**Código:** `backend/endpoints/lead_request_endpoints.py`

---

## 5. Fluxo completo (garantido: site no final)

```
┌──────────────────────────────────────────────────────────────────┐
│  USUÁRIO (admin.html)                                            │
│  ┌────────────┐    ┌────────────┐    ┌──────────────────────┐   │
│  │ Novo Pedido │ ->  │  Iniciar  │ ->  │  Pausar / Cancelar   │   │
│  │ (modal)     │    │  (botão)   │    │  (botões)            │   │
│  └────────────┘    └────────────┘    └──────────────────────┘   │
│        │                  │                                       │
│        ▼                  ▼                                       │
│   POST /api/lead-request   POST /api/lead-request/{id}/start     │
└───────────────────────────┼──────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  BACKEND — lead_request_service.py                               │
│  create_request() → INSERT lead_requests (status=enfileirado)   │
│  update_status()   → UPDATE status                               │
│  increment_delivered() → quantidade_entregue++ + auto-conclui   │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                ┌───────────┴────────────┐
                │                        │
                ▼                        ▼
   ┌──────────────────┐    ┌──────────────────────┐
   │ MODO MANUAL      │    │ MODO CRON            │
   │ Usuário clica    │    │ Worker-cron a cada 1h │
   │ "INICIAR"        │    │ POST /cron/tick      │
   └────────┬─────────┘    └──────────┬───────────┘
            │                         │
            └───────────┬─────────────┘
                        │
                        ▼
┌──────────────────────────────────────────────────────────────────┐
│  _enqueue_pedido() → enqueue_hunter(force=True)                  │
│  Hunter busca X leads (segmento + cidade do pedido)              │
│  Caio qualifica cada lead                                        │
│  lead_inventory: raw → qualifying → approved                     │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
┌──���───────────────────────────────────────────────────────────────┐
│  Production Tick (forçarLeadSupplyTick / automático)             │
│  _reserve_next() pega 1 lead aprovado                            │
│  job_queue.enqueue(tipo="pipeline_lead")                         │
│  lead_inventory.status = in_production                           │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  run_pipeline(state) — FSM pura                                  │
│  Hunter → Caio → Arquiteto → Builder → Quality Gate → DEPLOY    │
│                                                                  │
│  step_deploy():                                                  │
│    - Gera HTML final                                             │
│    - Salva em sites/{tenant_id}/{slug}-{lead_id}/index.html     │
│    - state.deploy_url = https://seunegociofralib.site/sites/... │
│    - UPDATE leads SET status='concluido', site_url=...          │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  handle_pipeline_job_finished(success=True)                      │
│  1. lead_inventory.status = 'site_done'                          │
│  2. increment_delivered(request_id, lead_id, deploy_url)        │
│     → lead_requests.quantidade_entregue++                       │
│     → se entregue >= total → status = 'concluido' (AUTO-PAUSA) │
│     → se modo=cron → agenda proxima_execucao +24h               │
│  3. enqueue_production_tick(next lead)                           │
│  4. sync_supply() → atualiza dashboard                           │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            ▼
                    ┌───────────────┐
                    │  SITE NO AR   │
                    │  ✅ deployado │
                    │  contador +1  │
                    └───────────────┘
```

---

## 6. Estados do pedido (transições)

```
                    ┌─────────────┐
                    │ enfileirado  │  (criado, aguardando start)
                    └──────┬──────┘
                           │ POST /start
                           ▼
                    ┌─────────────┐
          ┌───────  │ executando   │ ───────┐
          │         └──────┬──────┘        │
          │                │               │
          │   atingiu meta │  POST /pause  │
          │   (auto)       │               │
          │                ▼               │
          │         ┌─────────────┐       │ POST /start (retomar)
          │         │  pausado     │ ◄─────┘
          │         └──────┬──────┘
          │                │
          │   POST /cancel │
          │                ▼
          │         ┌─────────────┐
          └───────  │ cancelado    │
                    └─────────────┘
                           │
                  atingiu meta (auto)
                           ▼
                    ┌─────────────┐
                    │  concluido   │
                    └─────────────┘
```

---

## 7. Integração Hunter ↔ lead_requests

### Hunter batch respeita pedido
- `quantidade_por_execucao` → limite de leads por rodada (default 10)
- Hunter busca até `quantidade_por_execucao` leads por execução
- Não ultrapassa `quantidade_total` do pedido ativo

### Auto-pausa por meta
```python
# lead_request_service.py — increment_delivered()
status = CASE
    WHEN quantidade_entregue + 1 >= quantidade_total THEN 'concluido'
    WHEN modo = 'cron' THEN 'executando'
    ELSE 'executando'
END
```

### Modo cron
```python
# lead_request_endpoints.py — cron_tick()
due = get_due_cron_requests(db, now)  # proxima_execucao <= now
for pedido in due:
    _enqueue_pedido(db, tenant_id, pedido)  # dispara Hunter
    update_proxima_execucao(db, pedido["id"], now + 24h)
```

---

## 8. Frontend — arquitetura

### HTML (admin.html)
```
#painel-pedidos          ← seção "Meus Pedidos" (oculta se vazio)
#modalNovoPedido        ← modal de criação
  #np-nicho, #np-cidade  ← campos obrigatórios
  #np-qtd               ← quantidade_total
  #np-score             ← score_min
  #np-qtd-exec          ← quantidade_por_execucao
  #np-modo              ← select: manual/cron
  #np-cron-row          ← linha do cron (visível só se modo=cron)
  #np-cron              ← cron_schedule
  #np-status            ← feedback durante criação
```

### JavaScript
| Função | Path chamado | Quando |
|--------|-------------|--------|
| `abrirModalNovoPedido()` | — | Botão "+ NOVO PEDIDO" |
| `_npToggleCron()` | — | onchange do #np-modo |
| `criarNovoPedido()` | `POST /api/lead-request` | Submit do modal |
| `carregarPedidos()` | `GET /api/lead-request` | DOMContentLoaded + poll 10s |
| `iniciarPedido(id)` | `POST /api/lead-request/{id}/start` | Botão INICIAR/RETOMAR |
| `pausarPedido(id)` | `POST /api/lead-request/{id}/pause` | Botão PAUSAR |
| `cancelarPedido(id)` | `POST /api/lead-request/{id}/cancel` | Botão CANCELAR |

### Polling
- `carregarPedidos()` roda a cada 10s (integrado ao `_leadSupplyPoll` existente)
- Barra de progresso por pedido: `quantidade_entregue / quantidade_total`

---

## 9. Variáveis de ambiente

Nenhuma nova variável necessária. Usa as existentes:
- `LEAD_SUPPLY_HUNTER_BATCH` — limite de leads por rodada (default 8, max 20)
- `DATABASE_URL` — Postgres (obrigatória para todos os endpoints)
- `FRALIB_SITES_ROOT` — raiz onde sites são deployados

---

## 10. Testes pendentes (não implementados)

| Teste | Arquivo alvo |
|-------|-------------|
| Criar pedido manual → status=enfileirado | `lead_request_service.py` |
| Iniciar pedido → status=executando + Hunter enfileirado | `lead_request_endpoints.py` |
| increment_delivered → contador++ + auto-conclui | `lead_request_service.py` |
| Cron tick → processa pedidos due | `lead_request_endpoints.py` |
| E2E: pedido → Hunter → Caio → Builder → QG → Deploy → contador++ | `pipeline.py` |
| Frontend: criar pedido via modal → aparece na lista | `admin.html` |

---

## 11. Como estender

### Adicionar modo "agendamento único" (run once at specific time)
1. Adicionar campo `executar_em TIMESTAMP` na tabela
2. Em `cron_tick()`, após processar, mudar status para `concluido` (não `executando`)
3. No frontend, adicionar input de data/hora no modal

### Adicionar notificação por email quando pedido concluir
1. Hook em `increment_delivered()` quando status vira `concluido`
2. Chamar serviço de email com `deploy_url`

### Adicionar cancelamento se Hunter não atingir meta em X horas
1. Campo `timeout_horas INTEGER DEFAULT 24` na tabela
2. Em `cron_tick()`, checar pedidos `executando` onde `updated_at < now - timeout_horas`
3. Mudar status para `cancelado` + notificar usuário

---

## 12. Arquitetura de decisões

| Decisão | Razão |
|---------|-------|
| Tabela separada (`lead_requests`) ao invés de colunas em `lead_supply_config` | `lead_supply_config` é config global por tenant. Pedidos são entidades com ciclo de vida próprio (CRUD, status, quota) |
| `quantidade_entregue` incrementado APÓS deploy (não após Hunter encontrar lead) | Garante que "1 entregue" = "1 site no ar". Se pipeline falhar, não conta como entregue |
| Hook em `handle_pipeline_job_finished` ao invés de no Caio | Caio aprova leads, mas deploy é que garante site. Incrementar no deploy é o único ponto onde podemos afirmar "site saiu" |
| Auto-pausa por meta no `increment_delivered` ao invés de no Hunter | Hunter não sabe quantos leads viram sites. O contador só avança com deploy confirmado, então a pausa deve ser lá |
| `ensure_schema()` runtime (não Alembic) | Schema existente do lead_supply já usa runtime DDL. Mantém consistência |
| Frontend integrado ao painel existente (admin.html) ao invés de página separada | Usuário já opera pelo admin. Reduz atrito — não precisa navegar para outro lugar |
