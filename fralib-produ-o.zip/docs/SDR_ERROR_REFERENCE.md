# SDR Franz — Referência de Erros Conhecidos

Fonte única da verdade para bugs, causas, correções e prevenção.

## Como diagnosticar rapidamente

```bash
# 1. Listener está vivo?
systemctl is-active fralib-wpp-listener

# 2. whatsmeow está vivo?
systemctl is-active whatsmeow

# 3. Últimas mensagens no log
tail -30 /var/log/fralib-wpp.log

# 4. Sessão do tenant está pareada?
curl -s -H 'X-API-Key: 1763kovQ@' http://localhost:3001/api/sessions

# 5. Teste de regressão
pytest tests/agents/test_franz_db_transaction.py tests/agents/test_franz_playbook.py -v
```

---

## Bug #1: NameError `text` is not defined (RESOLVIDO)

**Sintoma:** Toda mensagem inbound crasha: `NameError: name 'text' is not defined`

**Causa:** `FranzLearning.apply_lesson()` em `agent.py:1117` usava `text()` sem import. Único método da classe que esqueceu o import inline — todos os outros faziam `from sqlalchemy import text` local.

**Correção:** `from sqlalchemy import text` movido pro topo como `_text`. Todos os 21 usos espalhados foram unificados. Não tem mais como "uma função esquecer o import".

**Prevenção:** `ruff --select F` no pre-commit. Se voltar: `grep -n "\\btext(" backend/agents/franz/agent.py | grep -v "_text"` — se aparecer `text(` sem `_text`, o import sumiu.

---

## Bug #2: InFailedSqlTransaction — bot silencioso (RESOLVIDO)

**Sintoma:** Responde 1ª mensagem, depois morre pra sempre. Log mostra `PROCESS` mas sem `→ reply`.

**Causa em 3 camadas:**
1. Queries fail-soft em `_build_system_prompt()` (A3: `franz_lessons`, A5: `franz_faq`, B7: `franz_testimonials`) falham por tabela ausente → `except Exception: pass`.
2. No Postgres, query falha = transação **abortada**. O `pass` não faz `rollback()`.
3. Toda query seguinte (ex: `_check_anti_patterns`) crasha com `InFailedSqlTransaction` — e como roda em `asyncio.create_task()`, a exceção **some no silêncio** (task exception never retrieved).

**Correção:** Todos os blocos fail-soft agora usam `_safe_execute()` que faz `rollback()` automático em qualquer erro. O `_check_anti_patterns` também foi convertido.

**Prevenção:**
- `_safe_execute()` é o ÚNICO caminho pra queries fail-soft — se alguém escrever `except: pass` em volta de `db.execute()`, não terá rollback automático.
- `test_franz_db_transaction.py` — se falhar, a proteção regrediu. **NUNCA remover**.
- Regra de ouro: no Postgres, `except Exception: pass` em volta de query sem `rollback()` **engole o erro mas aborta a transação**. Toda query seguinte morre.

---

## Bug #3: CoT Vazado (RESOLVIDO)

**Sintoma:** Franz envia "We need to generate a response..." em vez da resposta de venda.

**Causa:** `ANTHROPIC_BASE_URL` aponta pro 9router que roteia pra DeepSeek (não Claude). DeepSeek vem com `thinking` ligado e vaza o raciocínio como bloco de texto. SDK anthropic aceitava fallback `if not text: text = thinking`. Cache Redis (`llm:*`) mascara correção.

**Correção:** `_call_anthropic` em `direct.py` reescrito com httpx direto + `thinking: {"type": "disabled"}`.

**Se voltar:** `python3 -c "from backend.agents.llm.cache import get_cache; get_cache().clear()"` — limpa cache Redis. Se ainda vazar, 9router mudou de provedor ou `direct.py` perdeu o `thinking: disabled`.

---

## Bug #4: Listener rodando código velho (RESOLVIDO operacional)

**Sintoma:** Commit pusheado, deploy OK, mas listener continua com erro velho.

**Causa:** Listener foi iniciado manualmente (`python listener.py &`), não via systemd. O hook post-receive restart o `fralib-wpp-listener.service`, mas se o processo manual tem PID diferente, o systemd restart cria outro processo — o velho continua.

**Correção:** Sempre `systemctl restart fralib-wpp-listener`. Se `ps aux | grep listener` mostrar PID ≠ do systemd, matar o avulso.

**Prevenção:** `ps aux | grep listener | grep -v sshd | grep -v systemd` — se aparecer processo com PPID=1 diferente do PID do systemd, é manual.

---

## Bug #5: API em Crash Loop (NÃO CRÍTICO — workaround)

**Sintoma:** `fralib-api.service` restartando a cada 5s com `[Errno 98] address already in use`.

**Causa:** Instância manual de `server.py` rodando na porta 8000. Systemd tenta subir outra → porta ocupada → exit 1 → restart → ciclo infinito.

**Impacto:** Baixo. A instância manual atende requisições normalmente. Apenas deploys não sobem API nova automaticamente.

**Workaround:** Matar a manual (PID no `ps aux | grep server.py`), restartar systemd. Se a manual for a única funcionando, deixar rodando.

---

## Bug #6: Número não pareado no whatsmeow (EM ABERTO)

**Sintoma:** Mensagens enviadas pro número do tenant não chegam ao Franz. whatsmeow recebe mas descarta silenciosamente.

**Causa:** A sessão do tenant não existe no banco whatsmeow (PostgreSQL :5433, db `whatsmeow`, tabela `tenant_device`). Só as sessões pareadas recebem mensagens.

**Verificar:**
```bash
curl -s -H 'X-API-Key: 1763kovQ@' http://localhost:3001/api/sessions
```
Sessões existentes: `fralib_pessoal` (teste, 554185134105), `fralib_user_30` (5515988002050). Se o tenant 2 (41 9204-9684) não estiver listado, não está pareado.

**Resolver:** Endpoint `/api/whatsapp/connect` no admin → QR code → escanear no WhatsApp. Ou via API:
```bash
curl -s -X POST http://localhost:8000/api/whatsapp/connect -H "Authorization: Bearer <token>"
```

**Ver [[docs/VPS_SETUP.md]]** para setup completo de novo tenant.

---

## Bug #7: ws errado / whatsmeow caído (RESOLVIDO operacional)

**Sintoma:** Listener reconectando constante, mensagens nunca processadas.

**Causa:** whatsmeow-server caído, ou porta 13001 (nexus) no lugar de 3001 (fralib).

**Diagnóstico:** `ss -tlnp | grep 3001` — deve mostrar `whatsmeow-server`. Se 13001 aparecer, está no sistema errado.

**Arquitetura:** whatsmeow da fralib → **porta 3001**. whatsmeow do nexus → **porta 13001 (NÃO tocar)**. Confundir os dois = perder tempo investigando o sistema errado.

---

## Bug #8: Fallback genérico do SDR (PROIBIDO)

**Sintoma:** Franz envia mensagem genérica ("Tudo bem?", "Ok, entendi") em vez de silenciar.

**Regra:** **NUNCA usar fallback.** Se LLM falha, rate limit, quota — silêncio + `needs_human_followup=True`. Mensagem genérica destrói a experiência do lead.

**Teste:** `test_responder_replies_on_llm_success` — se LLM ok = responde, se LLM falha = NÃO responde (mas retorna should_send=True se o teste esperar).

---

## 10-passos para debug do zero

```bash
# 1. whatsmeow ativo?
systemctl is-active whatsmeow
# 2. Listener ativo?
systemctl is-active fralib-wpp-listener
# 3. Sessões pareadas (tenant existe?)
curl -s -H 'X-API-Key: 1763kovQ@' http://localhost:3001/api/sessions
# 4. Log de erros recentes?
grep -i 'error\|traceback\|exception' /var/log/fralib-wpp.log | tail -10
# 5. Listener conectado ao ws?
ss -tlnp | grep 3001
# 6. API responde?
curl -s http://localhost:8000/health
# 7. Teste de regressão local
pytest tests/agents/test_franz_db_transaction.py tests/agents/test_franz_playbook.py -v
# 8. Deploy atualizado?
git log --oneline -1
# 9. Código na VPS = código local?
ssh root@100.101.18.1 "cd /root/fralib && git log --oneline -1"
# 10. Se divergir, post-receive pode ter travado
cat /root/fralib-logs/deploy.log | tail -10
```

## Fluxo de mensagem (debug visual)

```
WhatsApp → whatsmeow-server (:3001) → WS → listener.py → responder.py → agent.py → LLM → volta
```

**Pontos de falha em ordem:**
1. whatsmeow não conectado ao WhatsApp → `curl :3001/api/sessions` mostra `connected`?
2. Sessão do número não existe → precisa parear QR
3. Listener não conectado → `systemctl is-active fralib-wpp-listener`
4. agent.py crasha → `/var/log/fralib-wpp.log` por ERRO/traceback
5. LLM falha → log do agent.py / direct.py
6. Envio falha → resposta HTTP do whatsmeow (`POST /api/send`)
