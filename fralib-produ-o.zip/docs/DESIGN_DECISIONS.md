"""Quem decide cada parte do site na esteira canonica.

Este arquivo documenta as decisoes de design tomadas por cada agente
na pipeline FraLib 7 etapas:
  Hunter -> Caio -> Arquiteto -> Builder -> Quality Gate -> Deploy -> Franz

CADEIA DE DECISAO (do lead ate o site):

1. Hunter (Overpass API / PlacesAPI / Nominatim)
   - FORNECE: dados REAIS do lead (lead_id, nome, telefone, endereco, lat/lng)
   - DECIDE: de qual lead partir
   - NAO DECIDE: cor, secoes, animacoes, copy

2. Caio (regras deterministicas)
   - FORNECE: tier (QUENTE/MORNO/FRIO/REJEITADO) + score (0-100)
   - DECIDE: se lead passa (regra: telefone valido + sem site = oportunidade)
   - NAO DECIDE: cor, secoes, copy

3. Arquiteto (LLM Sonnet 4.6 + design tokens deterministicos)
   - FORNECE: DesignerPRD (briefing final do site)
   - DECIDE:
     * Paleta de cores (primary/accent/dark) via theme_mapper
     * HERO H1 + subheadline + CTA primary
     * Secoes (titulo + content) — LLM decide estrutura
     * FAQs (5-8 perguntas)
     * SEO keywords
     * Motion directives (reveal, parallax, stagger)
   - NAO DECIDE: framework (zero Tailwind/Bootstrap), tipografia externa

4. Builder (OpenUI service Node.js porta 3333)
   - FORNECE: HTML final autocontido
   - DECIDE:
     * Design tokens em CSS variables (:root)
     * Tipografia (Google Fonts via <link rel>)
     * Grid/Flex de sessoes (CSS autoral, zero framework)
     * Composicao visual
     * Sistema data-attributes (data-fralib-reveal, data-fralib-parallax, ...)
   - NAO DECIDE: paleta (vem do Arquiteto), copy (vem do LLM), secoes (LLM)

5. Post-render Builder (injetores deterministicos):
   - LGPD banner (Lei 13.709/2018) — obrigatorio
   - Favicon SVG inline (data URI) + apple-touch-icon — usa cor primária do PRD
   - JSON-LD LocalBusiness com telefone extraído do CTA — SEO
   - GSAP 3 + Lenis + ScrollTrigger via CDN — motion cinematografico
   - Init script vanilla que liga tudo (sem framework JS)

6. Quality Gate (46 patches deterministicos)
   - FORNECE: relatorio de score (0-100)
   - DECIDE: se passa ou nao (>=50%); ate 3 retries para o Builder

7. Deploy
   - Salva em sites/<tenant>/<slug>-<lead_id8>/index.html + metadata.json
   - URL publica: https://seunegociofralib.site/sites/<rel>/

8. Franz (SDR FSM via whatsmeow)
   - FORNECE: outreach WhatsApp
   - DECIDE: tom de voz inicial, follow-ups
   - NAO DECIDE: design do site (ja publicado)

POR QUE OS SITES SAO UNICOS:
- Arquiteto gera paleta+copy diferentes para cada lead/segmento/cidade
- Builder compoem layout diferente para cada briefing
- Copy vem 100% do LLM (nao ha templates de texto)
- Animacoes vem do injetor deterministico (sempre mesmo runtime)
- LGPD/favicon/SEO sao deterministicos (sempre presentes)

O QUE E DETERMINISTICO:
- Framework da pagina (HTML/CSS/JS autoral, zero Tailwind/Bootstrap)
- Motion runtime (GSAP + Lenis + ScrollTrigger)
- LGPD banner
- Favicon (formato, nao escolha de icone)
- JSON-LD (estrutura LocalBusiness)
- Quality gate (46 checks)

O QUE VEM DO LLM (varia entre leads):
- Paleta de cores
- HERO H1 + subheadline
- CTAs
- Copia das secoes
- FAQs
- SEO keywords
- Motion directives especificas

PARA VARIAR AINDA MAIS OS SITES:
- Adicionar mais variety em prompts do Arquiteto
- Opcional: A/B de templates visuais no Builder (futuro, nao canonico hoje)
"""
