# Mapeamento: Agentes Existentes → 8 Constituições + Conselho + Master Prompt

## Visão Geral

| Constituição / Componente | Agente Existente | Status | Ação Necessária |
|---------------------------|------------------|--------|-----------------|
| **01 Business Constitution** | `hunter` + `caio` | 🟡 Parcial | Novo `business_board/agent.py` combinando ambos |
| **02 Market Constitution** | `hunter` (market_intel) | 🟡 Parcial | Novo `market_board/agent.py` estendendo market_intel do Hunter |
| **03 Brand Constitution** | `arquiteto` (parcial) | 🟡 Parcial | Novo `brand_board/agent.py` extraindo brand_dna do Arquiteto |
| **04 Strategic Constitution** | `caio` + `arquiteto` | 🟡 Parcial | Novo `strategic_board/agent.py` |
| **05 Creative Constitution** | `arquiteto` (design_lessons, archetype) | 🟡 Parcial | Novo `creative_board/agent.py` = Design Constitution v2.0 |
| **06 Experience Constitution** | — | ❌ Ausente | **NOVO** `experience_board/agent.py` |
| **07 Technical Constitution** | `builder` (generate.js tokens) | 🟡 Parcial | Novo `technical_board/agent.py` |
| **08 Quality Constitution** | `quality_gate` (Vision QA v2) | 🟡 Parcial | Novo `quality_board/agent.py` = QG v2 como Constituição |
| **Review Council (10 críticos)** | — | ❌ Ausente | **NOVO** `review_council/agent.py` |
| **Master Prompt** | `arquiteto` → `builder` | 🟡 Parcial | **NOVO** `master_prompt/agent.py` |
| **Orquestração (FSM)** | `manager/agent.py` | ✅ Base | **ESTENDER** FSM com 10+ estados + loop de review |

---

## Análise Detalhada por Agente Existente

### 1. `hunter/agent.py` (HunterAgent)
**Responsabilidade atual:**
- Fan-out providers (PlacesAPI + Google Maps + Nominatim fallback)
- Cache + merge por place_id
- Enriquecimento: digital, contexto, essencial
- Market intelligence: ICP, GEO entities, jornada, entidades, clusters, lacunas, autoridade, citações IA

**Mapeamento para Constituições:**
- **Business Constitution** (01): Dados brutos do lead (nome, segmento, cidade, ticket, margem) → entrada
- **Market Constitution** (02): `market_intel` já gera dominantes, em_crescimento, padrões, clichês, gaps → **REUTILIZÁVEL 80%**
- **Entrada para**: Brand, Strategic, Creative

**O que falta para Business Constitution:**
- `why_exists`, `transformation_delivered`, `problem_solved`, `market_position`, `kpi_sucesso`
- `caio` tem score/tier mas não `objetivo_site` (captar/autoridade/vender/agendar/educar/escalar)

---

### 2. `caio/agent.py` (Qualificador Determinístico)
**Responsabilidade atual:**
- Zero LLM, scoring 0-100: telefone, rating, reviews, website, fotos, cidade
- Tier: QUENTE/MORNO/FRIO/REJEITADO
- Paleta por segmento
- Rejeita redes conhecidas + telefones inválidos

**Mapeamento para Constituições:**
- **Business Constitution** (01): `qualificado` + `score` + `motivo` → valida se lead vale investimento
- **Strategic Constitution** (04): `tier` + `score` + `paleta_cores` → input para posicionamento/percepção de valor

**O que falta:**
- Não tem `objetivo_site` (captar/autoridade/vender/agendar/educar/escalar)
- Não tem `kpi_sucesso`
- Não tem `diferencial_unico`

---

### 3. `arquiteto/agent.py` (ArquitetoAgent - 553 linhas)
**Responsabilidade atual:**
- `gerar_prd()` → DesignerPRD completo
- SYSTEM_PROMPT com: AWWWARDS protocol, EEAT/GEO, 6 seções fixas, trust badges, VERDADE OU SILÊNCIO
- Deriva design_tokens via `theme_mapper.derive_design_tokens()`
- Injeta `market_intel` do Hunter no prompt
- DESIGN LESSONS do design_feedback_engine
- Entity tags, layout constraints, value prop over fact

**Mapeamento para Constituições:**
- **Brand Constitution** (03): Archetype, typography, palette, motion_language, brand_dna (ritmo, composição, fotografia, grid, espaçamento, textura, luz, motion, tipografia, micro_detalhe) → **JÁ EXISTE EM theme_mapper + ARCHETYPE_PROMPTS**
- **Creative Constitution** (05): Design Constitution v2.0 (17 regras) → **PARCIALMENTE NO SYSTEM_PROMPT**
- **Strategic Constitution** (04): `por_que_escolher`, `promessa_central`, `posicionamento`, `diferenciais`, `provas`, `objecoes` → **PARCIALMENTE NO PROMPT (value_prop_briefing, trust_badges)**
- **Master Prompt**: O prompt final que vai para o Builder → **JÁ É O USER_PROMPT DO ARQUITETO**

**O que falta para Brand Constitution:**
- `quem_somos` / `quem_nunca_seremos` explícitos
- `voice`: como_falamos, como_nao_falamos, vocabulário_proibido, tom
- `visual`: como_parecemos, como_nao_parecemos, cores_proibidas, fontes_proibidas, fotografia_estilo, textura
- `emocoes`: queremos_causar, proibimos_causar
- Teste do DNA: "Se remover o logo, a marca ainda é reconhecível?"

**O que falta para Creative Constitution (Design Constitution v2.0):**
- As 17 regras explícitas como validação (não só prompt)
- Narrative chain causal (não checklist)
- Proprietary Brand DNA (não archetype genérico)
- High-impact moment (Signature Element)
- Section layout variation enforcement
- Typography as protagonist enforcement
- Editorial footer enforcement
- AI-ready content enforcement

**O que falta para Strategic Constitution:**
- `como_vencer_concorrentes` explícito
- `percepcao_valor` mensurável
- `narrative_arc` estruturada

---

### 4. `builder/agent.py` (BuilderAgent - 127 linhas) + `generate.js` (OpenUI)
**Responsabilidade atual:**
- Proxy para OpenUI service (port 3333)
- `_prd_to_dict()` serializa DesignerPRD com design_tokens, layout_dna, design_system
- `render_site()` POST para OpenUI, fail-closed
- `_inject_system_extras()` aplica LGPD, favicon, JSON-LD, motion libs via inject.py + motion.py

**Mapeamento para Constituições:**
- **Technical Constitution** (07): Tokens → tailwind.config, Google Fonts URL, CSS globals, motion stack → **JÁ EXISTE EM theme_mapper + generate.js + motion.py**
- **Executor** do Master Prompt

**O que falta para Technical Constitution:**
- Spec técnico explícito: breakpoints, performance budget, accessibility baseline, browser support, CDN strategy, build pipeline
- Validação de que o HTML gerado cumpre a Constitution técnica

---

### 5. `quality_gate.py` (QualityGateAgent - Vision QA v2)
**Responsabilidade atual:**
- Vision LLM (gpt-4o-mini primary, 9router fallback) pontua design 0-10
- Repair loop regenera se score < 7.5
- Playwright async screenshot
- Persiste em `quality_gate_results` table

**Mapeamento para Constituições:**
- **Quality Constitution** (08): Vision QA v2 = Quality Constitution **JÁ FUNCIONANDO**
- **Review Council** input: Score do Vision QA é um dos 10 críticos

**O que falta para Quality Constitution:**
- Checklist determinístico das 8 Constituições anteriores (não só Vision score)
- Gates: Business ✓, Market ✓, Brand ✓, Strategic ✓, Creative ✓, Experience ✓, Technical ✓ → só então Quality

**O que falta para Review Council:**
- 10 críticos especializados (Creative Director, UX Lead, CRO, SEO, GEO, Motion, Brand, Art, Frontend, ICP)
- Qualquer nota < 95 → loop de refinamento automático (max 3 iterações)
- Síntese final antes de liberar para Builder

---

### 6. `franz/agent.py` (FranzAgent - 2000+ linhas)
**Responsabilidade atual:**
- SDR WhatsApp com memória semântica + episódica (pgvector)
- Auto-aprendizado (triggers: duplicate_msg, audio_missed, context_lost, objection_ignored, won/lost_sale)
- Whisper audio, playbook.json v2.0
- 12 eixos governança, 30 eixos conversão, LGPD consent hub
- MEDDIC scoring, territorial routing

**Mapeamento:**
- **Fora do pipeline de geração de site** — é pós-deploy (OUTREACH state no Manager FSM)
- Não participa das 8 Constituições + Review Council
- Mantém-se como está (state OUTREACH/DONE no Manager)

---

### 7. `manager/agent.py` (ManagerAgent - FSM Orchestrator)
**Responsabilidade atual:**
- Estados: INIT → HUNTING → QUALIFYING → DESIGNING → BUILDING → VALIDATING → PUBLISHING → OUTREACH → DONE/FAILED
- `run_pipeline()` sync com while loop permitindo retry Quality Gate → Builder
- `step_arquiteto()` chama `gerar_prd()` com design_tokens, layout_dna, design_system
- `step_builder()` reconstrói DesignerPRD do state, chama `render_site()`
- `step_quality_gate()` roda Vision QA v2 com repair loop
- Persiste QA results

**O que precisa mudar para nova arquitetura:**
```
ESTADOS ATUAIS (8)          →  ESTADOS NOVOS (18+)
INIT                        →  INIT
HUNTING                     →  HUNTING
QUALIFYING                  →  QUALIFYING
DESIGNING                   →  BUSINESS_CONSTITUTION
                            →  MARKET_CONSTITUTION
                            →  BRAND_CONSTITUTION
                            →  STRATEGIC_CONSTITUTION
                            →  CREATIVE_CONSTITUTION
                            →  EXPERIENCE_CONSTITUTION
                            →  TECHNICAL_CONSTITUTION
                            →  QUALITY_CONSTITUTION
                            →  REVIEW_COUNCIL (loop até 3x se <95)
                            →  MASTER_PROMPT_GENERATION
BUILDING                    →  BUILDING
VALIDATING                  →  VALIDATING (Vision QA v2)
PUBLISHING                  →  PUBLISHING
OUTREACH                    →  OUTREACH (Franz)
DONE/FAILED                 →  DONE/FAILED
```

---

## Agentes NOVOS Necessários (10)

| Agente | Arquivo | Baseado em | Complexidade |
|--------|---------|------------|--------------|
| `business_board` | `backend/agents/business_board/agent.py` | Hunter + Caio | Média |
| `market_board` | `backend/agents/market_board/agent.py` | Hunter.market_intel | Média |
| `brand_board` | `backend/agents/brand_board/agent.py` | Arquiteto + theme_mapper | Alta |
| `strategic_board` | `backend/agents/strategic_board/agent.py` | Caio + Arquiteto | Alta |
| `creative_board` | `backend/agents/creative_board/agent.py` | Arquiteto (Design Constitution v2.0) | **Muito Alta** |
| `experience_board` | `backend/agents/experience_board/agent.py` | **NOVO** | Alta |
| `technical_board` | `backend/agents/technical_board/agent.py` | Builder + theme_mapper + generate.js | Média |
| `quality_board` | `backend/agents/quality_board/agent.py` | Quality Gate v2 | Média |
| `review_council` | `backend/agents/review_council/agent.py` | **NOVO** | **Muito Alta** |
| `master_prompt` | `backend/agents/master_prompt/agent.py` | Arquiteto (prompt final) | Média |

---

## Estrutura de Dados: Constitution JSON

Cada board produz um JSON que alimenta o próximo:

```python
# business_board/output → market_board/input
BusinessConstitution = {
    "why_exists": str,
    "transformation_delivered": str,
    "problem_solved": str,
    "market_position": str,
    "ticket_medio": float,
    "margem": float,
    "diferencial_unico": str,
    "objetivo_site": list[str],  # ["captar", "autoridade", "vender", "agendar", "educar", "escalar"]
    "kpi_sucesso": str,
    "aprovado": bool,
    "blocking_reasons": list[str] | None
}

# market_board/output → brand_board/input
MarketConstitution = {
    "dominantes": [{"nome": str, "posicionamento": str, "fraqueza": str}],
    "em_crescimento": [{"nome": str, "estrategia": str}],
    "em_declinio": [{"nome": str, "motivo": str}],
    "padroes_mercado": list[str],
    "cliches_mercado": list[str],
    "oportunidades": list[str],
    "gaps_nao_atendidos": list[str],
    "aprovado": bool
}

# brand_board/output → strategic_board/input
BrandConstitution = {
    "quem_somos": str,
    "quem_nunca_seremos": str,
    "voice": {"como_falamos": str, "como_nao_falamos": str, "vocabulario_proibido": list[str], "tom": str},
    "visual": {"como_parecemos": str, "como_nao_parecemos": str, "cores_proibidas": list[str], "fontes_proibidas": list[str], "fotografia_estilo": str, "textura": str},
    "emocoes": {"queremos_causar": list[str], "proibimos_causar": list[str]},
    "brand_dna": {"ritmo": str, "composicao": str, "fotografia_tratamento": str, "grid": str, "espacamento": str, "textura": str, "luz": str, "motion": str, "tipografia": str, "micro_detalhe_recorrente": str},
    "aprovado": bool
}

# strategic_board/output → creative_board/input
StrategicConstitution = {
    "por_que_escolher_esta_empresa": str,
    "promessa_central": str,
    "posicionamento": str,
    "diferenciais": [{"nome": str, "prova": str, "impacto": str}],
    "provas": list[str],
    "objecoes_principais": [{"objecao": str, "resposta": str, "prova": str}],
    "como_vencer_concorrentes": str,
    "percepcao_valor": str,
    "narrative_arc": str,
    "aprovado": bool
}

# creative_board/output → experience_board/input
CreativeConstitution = {
    "narrative_chain": list[dict],  # cada elo: hook → tensão → payoff
    "brand_dna_proprietario": dict,  # não genérico
    "high_impact_moment": dict,      # Signature Element spec
    "section_layouts": list[dict],   # variação obrigatória por seção
    "typography_protagonist": dict,  # display font, scale, tracking, weight
    "editorial_footer": dict,
    "ai_ready_content": dict,
    "zero_checklist_optimization": bool,
    "creative_director_notes": str,
    "aprovado": bool
}

# experience_board/output → technical_board/input
ExperienceConstitution = {
    "journey_map": list[dict],       # stage, emotion, action, friction, delight
    "interaction_patterns": list[dict],
    "motion_choreography": dict,     # scroll, hover, load, transition
    "content_strategy": dict,        # hierarchy, progressive disclosure, AI-ready
    "accessibility_baseline": dict,  # WCAG AA + reduced motion
    "performance_budget": dict,      # LCP, INP, CLS targets
    "aprovado": bool
}

# technical_board/output → quality_board/input
TechnicalConstitution = {
    "tokens_spec": dict,             # tailwind.config, fonts, colors, radius, spacing
    "breakpoints": list[str],
    "performance_budget": dict,
    "accessibility_spec": dict,
    "browser_support": list[str],
    "cdn_strategy": dict,
    "build_pipeline": dict,
    "html_structure_rules": list[str],  # semantic, no inline handlers, etc.
    "aprovado": bool
}

# quality_board/output → review_council/input
QualityConstitution = {
    "vision_qa_spec": dict,          # gpt-4o-mini prompt, thresholds, repair_loop
    "deterministic_checks": list[dict],  # 8 constitutions compliance
    "gates": list[str],              # ["business", "market", "brand", "strategic", "creative", "experience", "technical"]
    "aprovado": bool
}

# review_council/output → master_prompt/input
ReviewCouncilOutput = {
    "scores": {"creative_director": int, "ux_lead": int, "cro_specialist": int, "seo_lead": int, "geo_lead": int, "motion_designer": int, "brand_director": int, "art_director": int, "frontend_lead": int, "icp": int},
    "min_score": int,
    "all_pass": bool,
    "feedback_by_critic": dict,
    "refinement_instructions": list[str],
    "iteration": int,
    "max_iterations": 3
}

# master_prompt/output → builder/input
MasterPrompt = {
    "system_prompt": str,
    "user_prompt": str,
    "design_tokens": dict,
    "layout_dna": dict,
    "design_system": dict,
    "constraints": list[str],
    "entity_tags": dict,
    "layout_constraints": list[str],
}
```

---

## Plano de Implementação (Fases)

### Fase 1: Fundações (1-2 dias)
1. Criar estrutura de pastas para 10 novos agentes
2. Definir dataclasses/Pydantic models para cada Constitution JSON
3. Criar `base_constitution.py` com classe base + validação `aprovado` + `blocking_reasons`
4. Estender `manager/agent.py` FSM com 10 novos estados + loop de review

### Fase 2: Business + Market (1 dia)
5. `business_board/agent.py` - combina Hunter lead_data + Caio qualification
6. `market_board/agent.py` - extrai e expande `HunterAgent._market_intelligence()`

### Fase 3: Brand + Strategic (2 dias)
7. `brand_board/agent.py` - extrai Brand DNA do theme_mapper + Arquiteto
8. `strategic_board/agent.py` - sintetiza positioning + promise + differentiation

### Fase 4: Creative Constitution (3 dias) - **CORE**
9. `creative_board/agent.py` - Implementa Design Constitution v2.0 (17 regras) como validação determinística + LLM
   - Narrative chain causal
   - Proprietary Brand DNA
   - High-impact moment spec
   - Section layout variation enforcement
   - Typography protagonist enforcement
   - Editorial footer enforcement
   - AI-ready content enforcement
   - Zero checklist optimization

### Fase 5: Experience + Technical (1.5 dias)
10. `experience_board/agent.py` - Journey map, motion choreography, accessibility baseline
11. `technical_board/agent.py` - Tokens spec, performance budget, HTML structure rules

### Fase 6: Quality + Review Council + Master Prompt (2 dias)
12. `quality_board/agent.py` - Vision QA v2 + 8 constitutions deterministic gates
13. `review_council/agent.py` - 10 critics, score <95 → refinement loop (max 3)
14. `master_prompt/agent.py` - Gera prompt mestre final para Builder

### Fase 7: Integração + Testes (1.5 dias)
15. Integrar tudo no `manager/agent.py` novo FSM
16. Testes end-to-end: `pytest tests/agents/test_constitution_pipeline.py`
17. Smoke test: `python pipeline.py smoke --dry-run`

---

## Riscos e Mitigações

| Risco | Impacto | Mitigação |
|-------|---------|-----------|
| Creative Board muito complexo (17 regras validadas) | Atraso Fase 4 | Implementar validações determinísticas primeiro, LLM depois |
| Review Council 10 critics = 10 LLM calls por iteração | Latência/custo | Paralelizar critics; cache prompts; max 3 iterações |
| Manager FSM quebra com 18 estados | Regressão pipeline | Testes unitários por transição de estado; feature flag rollout |
| Brand DNA "teste do logo" subjetivo | Falso negativo | Heurística: brand_dna tem 10 campos únicos → score de unicidade |
| Massa Corporal bug (inject.py linha 484) persiste | Conteúdo após footer | Fix separado e prioritário (fora deste plano) |

---

## Decisões de Design

1. **Cada board = agente independente** com `agent.py` + `contracts.py` (Pydantic models) + `prompts.py`
2. **Validação `aprovado: bool` obrigatória** em toda Constitution output - se false, pipeline para com `blocking_reasons`
3. **Manager FSM persiste cada Constitution** no `PipelineState` (dataclass) para debug/auditoria
4. **Review Council roda em paralelo** (10 agents simultâneos) - `asyncio.gather`
5. **Master Prompt é a única coisa que vai pro Builder** - tudo antes é preparação
6. **Franz mantém-se fora** - só entra no state OUTREACH pós-PUBLISHING
7. **Quality Gate v2 (Vision QA) vira um dos 10 critics** (o "QA Lead") no Review Council, não gate isolado