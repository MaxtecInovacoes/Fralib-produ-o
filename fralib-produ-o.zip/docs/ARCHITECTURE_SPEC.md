# ARCHITECTURE_SPEC.md — Knowledge-Centered OS

**Versão:** 1.0 | **Data:** 2026-07-21 | **Status:** Source of Truth

---

## 0. Prefácio: Por que este documento existe

O FraLib está evoluindo de **pipeline linear** (Hunter → Caio → Arquiteto → Builder → QG → Deploy → Franz) para **Knowledge-Centered OS**: uma plataforma onde *cada decisão deixa rastro*, *cada padrão é mensurável* e *novas capacidades nascem certificadas*.

> **Regra de Ouro:** A arquitetura dirige o código. Nunca o código dirige a arquitetura.

**Ordem de implementação obrigatória:**
1. Architecture Spec (este doc)
2. Contracts (Pydantic/Avro)
3. Tests (RED first)
4. Implementation (GREEN)
5. Validation (CI + Shadow Mode)

---

## 1. System Overview

### 1.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        KNOWLEDGE-CENTERED OS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────┐   ┌────────────┐  │
│  │   HUNTER     │   │    CAIO      │   │  ARQUITETO   │   │  BUILDER   │  │
│  │  (Discovery) │──▶│ (Qualify)    │──▶│ (Strategy)   │──▶│ (Generate) │  │
│  └──────┬───────┘   └──────┬───────┘   └──────┬───────┘   └──────┬─────┘  │
│         │                  │                  │                  │         │
│         ▼                  ▼                  ▼                  ▼         │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    KNOWLEDGE CORE (Event Store 2.0)                  │  │
│  │  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  ┌────────────┐  │  │
│  │  │  Journal    │  │  Confidence  │  │  Hypothesis│  │  Semantic  │  │  │
│  │  │  (Events)   │  │  Engine      │  │  Registry  │  │  Diff      │  │  │
│  │  └─────────────┘  └──────────────┘  └────────────┘  └────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│         │                  │                  │                  │         │
│         ▼                  ▼                  ▼                  ▼         │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    CAPABILITY REGISTRY                               │  │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐    │  │
│  │  │ Manifest   │  │ Contracts  │  │ Cert Model │  │ Versioning │    │  │
│  │  └────────────┘  └────────────┘  └────────────┘  └────────────┘    │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│         │                                                                │
│         ▼                                                                │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    ORCHESTRATOR (FSM Manager)                        │  │
│  │  Feature Flag: FRALIB_AGENCY_OS (off | shadow | on)                 │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Core Principles

| Princípio | Descrição |
|-----------|-----------|
| **Knowledge-First** | Todo estado deriva do Event Store; não há "estado implícito" |
| **Domain Language** | Eventos técnicos mapeiam 1:1 para linguagem de agência (MarketAnalyzed → MarketOpportunityDiscovered) |
| **Confidence-Driven** | Patterns têm `confidence_score` (0.5→1.0); `status='confiavel'` em ≥0.7 |
| **Capability-Centric** | Novas features = Capabilities certificadas, não código solto |
| **Shadow-First Rollout** | Flag `FRALIB_AGENCY_OS` controla: off → shadow (paralelo) → on progressivo |
| **FSM, Not Graph** | Orquestrador é Máquina de Estados Finitos pura (sem LangGraph) |
| **Website-First** | Capabilities servem o fluxo Website; generalização vem depois |

---

## 2. Domain Language (Event Taxonomy)

### 2.1 Mapa Técnico → Agência (Lista Fechada)

| Technical Key | Domain Event (Agência) | Trigger | Payload Essencial |
|---------------|------------------------|---------|-------------------|
| `market_analyzed` | **MarketOpportunityDiscovered** | Hunter finaliza | `segmento`, `cidade`, `market_intelligence`, `hypothesis` |
| `lead_qualified` | **LeadQualified** | Caio aprova | `score_caio`, `icp_fit`, `hypothesis` |
| `positioning_chosen` | **PromiseValidated** | Arquiteto define promise | `promise`, `positioning`, `archetype`, `hypothesis` |
| `narrative_locked` | **NarrativeLocked** | PRD aprovado | `narrative`, `journey`, `hero`, `hypothesis` |
| `identity_approved` | **IdentityApproved** | Design tokens aprovados | `palette`, `typography`, `layout_family`, `signature`, `hypothesis` |
| `artifact_generated` | **ArtifactGenerated** | Builder entrega HTML | `html_hash`, `sections_count`, `hypothesis` |
| `quality_concern_raised` | **QualityConcernRaised** | QG v2 < threshold | `vision_score`, `issues`, `hypothesis` |
| `quality_confirmed` | **QualityConfirmed** | QG v2 ≥ threshold | `vision_score`, `strengths`, `patterns_reinforced` |
| `narrative_refined` | **NarrativeRefined** | Repair loop altera PRD | `semantic_diff`, `rationale`, `changed_fields` |
| `project_published` | **ProjectPublished** | Deploy concluído | `url`, `deploy_id`, `hypothesis` |

### 2.2 Validação

```python
# backend/core/knowledge_journal.py:16-30
EVENT_TYPES: dict[str, str] = { ... }  # Lista FECHADA
VALID_EVENT_TYPES = set(EVENT_TYPES.values())

# record() levanta ValueError se event_type ∉ EVENT_TYPES
```

---

## 3. Knowledge Journal (Event Store 2.0)

### 3.1 Schema (PostgreSQL)

```sql
CREATE TABLE knowledge_journal (
    id          BIGSERIAL PRIMARY KEY,
    project_id  VARCHAR(64) NOT NULL,      -- lead_id
    seq         INTEGER NOT NULL,          -- sequência por projeto
    event_type  VARCHAR(64) NOT NULL,      -- Domain Event (ex.: MarketOpportunityDiscovered)
    hypothesis  TEXT,                      -- Hipótese estratégica (obrigatório nas decisões)
    payload     JSONB NOT NULL,            -- Dados contextuais
    criado_em   TIMESTAMP DEFAULT NOW(),
    UNIQUE (project_id, seq)
);
CREATE INDEX idx_kj_project ON knowledge_journal(project_id);
```

### 3.2 API

```python
# backend/core/knowledge_journal.py

def record(
    project_id: str,
    event_type: str,        # Chave técnica (ex.: "narrative_locked")
    hypothesis: str | None, # Obrigatório em decisões estratégicas
    payload: dict[str, Any]
) -> int:                   # Retorna seq atribuído

def stream(project_id: str) -> list[dict[str, Any]]:
    # Retorna eventos ordenados por seq
```

### 3.3 Regras de Uso

| Regra | Detalhe |
|-------|---------|
| **Hipótese obrigatória** | Em `positioning_chosen`, `narrative_locked`, `identity_approved`, `quality_concern_raised`, `narrative_refined` |
| **Imutabilidade** | Eventos nunca são editados/deletados; correção = novo evento |
| **Sequência por projeto** | `seq` garante ordem causal dentro do lead |
| **Payload tipado** | Cada event_type tem schema esperado (ver seção Contracts) |

---

## 4. Confidence Engine & Pattern Library

### 4.1 Conceito

Patterns extraídos de projetos bem-sucedidos (`vision_score ≥ 8.5`) ganham `confidence_score` que evolui:

```
Novo pattern (score 8.5+) → confidence = 0.5
  │
  ├── Reforçado novamente → +0.1 (teto 1.0)
  ├── Contraditado (score < 7.5) → -0.15 (piso 0.0)
  │
  └── status = 'confiavel' QUANDO confidence ≥ 0.7
```

### 4.2 Schema (PostgreSQL)

```sql
CREATE TABLE pattern_library (
    id              BIGSERIAL PRIMARY KEY,
    kind            VARCHAR(32) NOT NULL,     -- archetype | layout_family | signature | component | motion
    spec            JSONB NOT NULL,           -- Especificação do pattern
    confidence_score NUMERIC(3,2) DEFAULT 0.5,
    status          VARCHAR(16) DEFAULT 'candidato',  -- candidato | confiavel | depreciado
    evidence_count  INTEGER DEFAULT 1,
    last_reinforced TIMESTAMP,
    created_at      TIMESTAMP DEFAULT NOW(),
    UNIQUE (kind, spec)                       -- Deduplicação por conteúdo
);
CREATE INDEX idx_pl_kind_status ON pattern_library(kind, status);
```

### 4.3 API

```python
# backend/core/confidence.py

def reinforce(patterns: list[dict], vision_score: float) -> None:
    """
    patterns: [{kind, spec, project_id}, ...]
    vision_score: score do Quality Gate v2 (0-10)
    """
    # Se vision_score >= 8.5 → upsert +0.1 confidence
    # Se vision_score < 7.5  → -0.15 confidence
    # Emite QualityConfirmed / QualityConcernRaised no Knowledge Journal
```

### 4.4 Integração com Quality Gate v2

```python
# backend/agents/builder/quality_gate_v2/__init__.py:110-115
patterns = extract_patterns_from_prd(prd, lead_id)
reinforce(patterns, vision_result.score)  # Executa APÓS vision eval, ANTES de repair
```

### 4.5 Pattern Ranking (para Arquiteto/Builder)

```python
def rank_patterns(kind: str, context: dict) -> list[dict]:
    """
    Retorna patterns ordenados por:
    1. status = 'confiavel' primeiro
    2. confidence_score DESC
    3. evidence_count DESC
    Filtrados por compatibilidade com context (segmento, icp, etc.)
    """
```

---

## 5. Hypothesis Registry

### 5.1 Propósito

Capturar **por que** uma decisão foi tomada, não apenas **o que** foi decidido. Permite:
- Auditoria de decisões estratégicas
- Aprendizado: hipótese validada vs. invalidada
- Correlação: hipótese → outcome (vision_score, conversão)

### 5.2 Schema (PostgreSQL)

```sql
CREATE TABLE hypothesis_registry (
    id              BIGSERIAL PRIMARY KEY,
    project_id      VARCHAR(64) NOT NULL,
    event_seq       INTEGER NOT NULL,           -- FK para knowledge_journal.seq
    hypothesis      TEXT NOT NULL,              -- Texto da hipótese
    hypothesis_type VARCHAR(32) NOT NULL,       -- positioning | narrative | identity | quality | repair
    status          VARCHAR(16) DEFAULT 'open', -- open | validated | invalidated | superseded
    validated_at    TIMESTAMP,
    validation_note TEXT,
    created_at      TIMESTAMP DEFAULT NOW(),
    FOREIGN KEY (project_id, event_seq) REFERENCES knowledge_journal(project_id, seq)
);
CREATE INDEX idx_hr_project ON hypothesis_registry(project_id);
```

### 5.3 Fluxo

```
Decision Point (Arquiteto/Builder/QG)
       │
       ▼
record(project_id, event_type, hypothesis="...", payload={...})
       │
       ├──▶ knowledge_journal (evento)
       └──▶ hypothesis_registry (hipótese vinculada ao seq)
              │
              ▼ (futuro: validação automática via outcome)
       status: 'validated' | 'invalidated'
```

### 5.4 Tipos de Hipótese

| Tipo | Contexto | Exemplo |
|------|----------|---------|
| `positioning` | PromiseValidated | "Promise 'resultados em 30 dias' ressoa com academias que perdem alunos no verão" |
| `narrative` | NarrativeLocked | "Journey baseada em 'medo de estagnar' > 'desejo de crescer' para esse ICP" |
| `identity` | IdentityApproved | "Layout 'editorial-bold' + fonte Anton transmite autoridade para segmento premium" |
| `quality` | QualityConcernRaised | "Score 6.2: hero sem contrast → hipótese: aumentar tipografia para 18vw resolve" |
| `repair` | NarrativeRefined | "Mudança de palette warm→cool aumentou score 6.2→8.1; hipótese: cool = confiança B2B" |

---

## 6. Semantic Diff Engine

### 6.1 Propósito

Comparar **domínios de tokens/PRD** (não strings brutas) e emitir narrativa explicativa para o Knowledge Journal.

### 6.2 Domain Map

```python
# backend/core/semantic_diff.py:10-50
DOMAIN_MAP = {
    "promise":          {"weight": 1.0, "category": "strategy"},
    "narrative":        {"weight": 0.9, "category": "strategy"},
    "positioning":      {"weight": 0.9, "category": "strategy"},
    "archetype":        {"weight": 0.8, "category": "identity"},
    "palette":          {"weight": 0.7, "category": "identity"},
    "typography":       {"weight": 0.7, "category": "identity"},
    "layout_family":    {"weight": 0.8, "category": "layout"},
    "hero":             {"weight": 0.9, "category": "layout"},
    "sections":         {"weight": 0.6, "category": "layout"},
    "signature":        {"weight": 0.8, "category": "identity"},
    "motion":           {"weight": 0.5, "category": "motion"},
    "schema":           {"weight": 0.4, "category": "seo"},
    "entities":         {"weight": 0.4, "category": "seo"},
    "keywords":         {"weight": 0.3, "category": "seo"},
}
```

### 6.3 API

```python
# backend/core/semantic_diff.py

def diff(before: dict, after: dict) -> dict:
    """
    Returns:
    {
        "changed": [...],      # Lista de campos alterados com before/after
        "unchanged": [...],    # Campos estáveis
        "rationale": "...",    # Narrativa em linguagem natural
        "impact_score": 0.0-1.0 # Ponderado por DOMAIN_MAP weights
    }
    """

def format_for_journal(diff_result: dict) -> dict:
    """
    Formata para payload do Knowledge Journal (event_type="narrative_refined")
    """
```

### 6.4 Integração no Repair Loop

```python
# backend/agents/builder/quality_gate_v2/__init__.py:128-160
prd_before = prd_to_dict(prd)
repair_result = await repair_loop(...)
if repair_result.success:
    prd_after = prd_to_dict(prd)
    diff_result = diff(prd_before, prd_after)
    journal_entry = format_for_journal(diff_result)
    record(project_id=lead_id, event_type="narrative_refined",
           hypothesis=journal_entry["rationale"], payload=journal_entry)
```

---

## 7. Strategic Insights Flow (Hunter → Arquiteto)

### 7.1 Hunter: Market Intelligence Generation

```python
# backend/agents/hunter/agent.py:180-250 (build_market_intelligence)

def build_market_intelligence(leads: list, segmento: str, cidade: str) -> dict:
    """
    Agrega dados brutos → insights estratégicos consumíveis pelo Arquiteto
    Returns:
    {
        "market_size": {...},
        "competitive_landscape": {...},
        "icp_signals": {...},
        "positioning_gaps": [...],       # Oportunidades de positioning
        "narrative_angles": [...],       # Ângulos de narrativa não explorados
        "design_preferences": {...},     # Cores, layouts, tons preferidos no segmento
        "conversion_drivers": [...],     # O que converte nesse mercado
        "risk_factors": [...],
        "confidence": 0.0-1.0,
        "generated_at": "..."
    }
    """
```

### 7.2 Contracts

```python
# backend/agents/hunter/contracts.py
class HunterResult(BaseModel):
    leads: list[LeadData]
    market_intelligence: Optional[dict] = None  # NOVO: insights estratégicos
    segmento: str
    cidade: str
    total_found: int
    qualified_count: int
```

### 7.3 Arquiteto: Consumo no Prompt

```python
# backend/agents/arquiteto/agent.py:231-233
market_intel = lead_data.get("market_intelligence", {})
if market_intel:
    prompt_parts.append(f"\n📊 MARKET INTELLIGENCE (Hunter):\n{json.dumps(market_intel, indent=2, ensure_ascii=False)}")
```

### 7.4 DesignerPRD Enriquecido

```python
# backend/agents/arquiteto/agent.py (DesignerPRD)
class DesignerPRD(BaseModel):
    # ... campos existentes ...
    design_tokens: dict = {}          # palette, typography, spacing
    layout_dna: dict = {}             # layout_family, grid, rhythm
    design_system: dict = {}          # components, patterns, motion tokens
    strategic_rationale: str = ""     # Por que essas escolhas (baseado em market_intel)
```

---

## 8. Quality Gate v2 (Vision LLM + Repair Loop)

### 8.1 Pipeline

```
HTML + PRD + Segmento
       │
       ▼
┌──────────────────┐
│  Render +        │  → Playwright (desktop 1440x900 + mobile 375x812)
│  Screenshot      │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Vision Eval     │  → OpenRouter gpt-4o-mini (primary) / 9router (fallback)
│  (0-10 score)    │     Threshold padrão: 7.5
└────────┬─────────┘
         │
    ┌────┴────┐
    ▼         ▼
≥ 7.5      < 7.5
    │         │
    ▼         ▼
Confidence  Repair Loop
Engine      (max 2 tentativas)
    │         │
    │         ▼
    │   ┌─────────────┐
    │   │ Semantic    │  → Compara PRD before/after
    │   │ Diff        │  → Emite NarrativeRefined
    │   └─────────────┘
    │         │
    ▼         ▼
Final HTML + Metadata (QA2Result)
```

### 8.2 Vision Evaluation Criteria

| Critério | Peso | Descrição |
|----------|------|-----------|
| **Visual Hierarchy** | 0.25 | Escala, contraste, foco |
| **Brand Consistency** | 0.20 | Tokens aplicados corretamente |
| **Layout Quality** | 0.20 | Grid, ritmo, whitespace |
| **Motion/Interaction** | 0.15 | Transições, hover, micro-interactions |
| **Accessibility** | 0.10 | Contraste, alt-text, focus states |
| **Conversion Clarity** | 0.10 | CTA visibilidade, fluxo |

### 8.3 Thresholds & Actions

| Score | Status | Ação |
|-------|--------|------|
| **≥ 8.5** | Excellence | `reinforce(patterns, score)` → Confidence Engine |
| **7.5 – 8.49** | Pass | Deploy sem repair |
| **< 7.5** | Fail | Repair Loop (max 2 tentativas) |
| **Repair success** | Recovered | `NarrativeRefined` no Journal |
| **Repair fail** | Blocked | `QualityConcernRaised` + needs_human_review |

### 8.4 Accessibility Determinística (Fase 9.0)

```javascript
// openui-service/src/generate.js — applyEliteRefinements()
- alt-text obrigatório em TODAS as imagens
- scrim (overlay) em hero com texto sobre imagem
- text-shadow em headlines sobre backgrounds complexos
// Vision NÃO penaliza mais o básico; gargalo 7.5→9.0 é estética (Fase 9.1+)
```

---

## 9. Capability Registry

### 9.1 Conceito

**Capability** = unidade de funcionalidade certificada, versionada, com contrato explícito. Não é "módulo" nem "serviço" — é **capacidade declarada e testada**.

### 9.2 Manifest Schema

```yaml
# capabilities/{capability_id}/manifest.yaml
capability_id: "website.hero.v1"
version: "1.2.0"
name: "Hero Section Generator"
description: "Gera seção hero com tipografia monumental, grain seletivo, assimetria"
category: "website"           # website | intelligence | communication | automation
maturity: "certified"         # draft | candidate | certified | deprecated
entry_point: "backend.agents.builder.capabilities.hero:generate_hero"
contracts:
  input: "HeroInputSchema"    # Pydantic model
  output: "HeroOutputSchema"  # Pydantic model
dependencies:
  - "design.tokens.v1"
  - "layout.grid.v1"
certification:
  min_vision_score: 8.0
  test_coverage: 85
  shadow_validated: true
  rollout_percentage: 100
tags: ["hero", "above-fold", "conversion"]
```

### 9.3 Contracts (Pydantic)

```python
# capabilities/{capability_id}/contracts.py
from pydantic import BaseModel, Field
from typing import Literal

class HeroInputSchema(BaseModel):
    promise: str = Field(..., min_length=10, max_length=200)
    archetype: Literal["authority", "companion", "challenger", "innovator"]
    layout_family: Literal["editorial-bold", "split-asymmetry", "centered-focus"]
    design_tokens: DesignTokensSchema
    market_intelligence: Optional[MarketIntelSchema] = None

class HeroOutputSchema(BaseModel):
    html: str
    css: str
    js: Optional[str] = None
    tokens_used: dict
    vision_score_predicted: float
    semantic_fingerprint: str  # Hash para diff futuro
```

### 9.4 Certification Model

| Stage | Critério | Validação |
|-------|----------|-----------|
| **draft** | Código existe, testes básicos | Dev only |
| **candidate** | Coverage ≥ 80%, Vision ≥ 7.5 em 3 runs | CI automático |
| **certified** | Coverage ≥ 85%, Vision ≥ 8.0 em 10 runs shadow, Zero CRITICAL bugs | **Human approval + Certificação automática** |
| **deprecated** | Substituído por versão superior | Migration path documentado |

### 9.5 Versioning & Compatibility

```
MAJOR.MINOR.PATCH
  │     │     └─ Bug fix, compatível
  │     └────── Nova funcionalidade, backward-compatible
  └─────────── Breaking change → nova capability_id (ex.: website.hero.v2)
```

**Registry API:**
```python
class CapabilityRegistry:
    def register(manifest: Manifest) -> CapabilityId
    def get(capability_id: str, version: str = "latest") -> Capability
    def list(category: str = None, maturity: str = None) -> list[Capability]
    def certify(capability_id: str, version: str, evidence: CertificationEvidence) -> bool
    def deprecate(capability_id: str, version: str, replacement: str) -> None
```

---

## 10. Orchestrator (FSM Manager)

### 10.1 Estados da Pipeline

```python
# backend/agents/manager/agent.py
class PipelineState(Enum):
    INTAKE          = "intake"           # Lead recebido
    MARKET_ANALYSIS = "market_analysis"  # Hunter
    QUALIFICATION   = "qualification"    # Caio
    STRATEGY        = "strategy"         # Arquiteto (PRD)
    GENERATION      = "generation"       # Builder
    QUALITY_GATE    = "quality_gate"     # QG v2
    DEPLOY          = "deploy"           # Deploy
    DONE            = "done"
    FAILED          = "failed"
    NEEDS_HUMAN     = "needs_human"
```

### 10.2 Transições & Journal Records

| Estado Atual | Próximo | Trigger | Journal Event |
|--------------|---------|---------|---------------|
| INTAKE | MARKET_ANALYSIS | Lead criado | — |
| MARKET_ANALYSIS | QUALIFICATION | Hunter completo | `MarketOpportunityDiscovered` |
| QUALIFICATION | STRATEGY | Caio score ≥ threshold | `LeadQualified` |
| QUALIFICATION | NEEDS_HUMAN | Caio score < threshold | — |
| STRATEGY | GENERATION | PRD aprovado | `PromiseValidated` + `NarrativeLocked` + `IdentityApproved` |
| GENERATION | QUALITY_GATE | HTML gerado | `ArtifactGenerated` |
| QUALITY_GATE | DEPLOY | Vision ≥ 7.5 | `QualityConfirmed` |
| QUALITY_GATE | GENERATION | Vision < 7.5 + repair | `QualityConcernRaised` → `NarrativeRefined` |
| QUALITY_GATE | NEEDS_HUMAN | Repair falhou 2x | `QualityConcernRaised` |
| DEPLOY | DONE | Deploy OK | `ProjectPublished` |
| * | FAILED | Exceção não tratada | — |

### 10.3 Feature Flag Control

```python
# backend/agents/manager/agent.py
FRALIB_AGENCY_OS = os.getenv("FRALIB_AGENCY_OS", "off")  # off | shadow | on

def run_pipeline(state: PipelineState) -> PipelineState:
    if FRALIB_AGENCY_OS == "off":
        return run_legacy_pipeline(state)  # Pipeline linear atual
    elif FRALIB_AGENCY_OS == "shadow":
        # Executa AMBOS em paralelo, compara resultados, loga diff_report.json
        legacy_result = run_legacy_pipeline(state.copy())
        new_result = run_capability_pipeline(state.copy())
        emit_shadow_diff(legacy_result, new_result)
        return legacy_result  # Produção usa legacy
    else:  # "on"
        return run_capability_pipeline(state)  # Nova arquitetura
```

### 10.4 Shadow Mode: Diff Report

```json
// diff_report.json (emitido a cada run em shadow)
{
  "run_id": "run_20260721_143022_abc123",
  "lead_id": "lead_456",
  "timestamp": "2026-07-21T14:30:22Z",
  "legacy": {
    "final_state": "done",
    "vision_score": 7.8,
    "duration_ms": 45000,
    "html_hash": "sha256:...",
    "journal_events": 7
  },
  "capability": {
    "final_state": "done",
    "vision_score": 8.3,
    "duration_ms": 52000,
    "html_hash": "sha256:...",
    "journal_events": 10,
    "capabilities_used": ["website.hero.v1", "website.sections.v1", ...]
  },
  "diff": {
    "vision_delta": +0.5,
    "duration_delta_ms": +7000,
    "events_delta": +3,
    "html_similarity": 0.87,
    "divergences": [
      {"stage": "strategy", "field": "design_tokens.palette", "legacy": "...", "new": "..."}
    ]
  }
}
```

---

## 11. Migration & Rollout Strategy

### 11.1 Feature Flag: `FRALIB_AGENCY_OS`

| Valor | Comportamento | Uso |
|-------|---------------|-----|
| `off` (default) | Pipeline legacy apenas | Produção atual |
| `shadow` | Legacy + Capability paralelos, diff_report | Validação pré-produção |
| `on` | Capability pipeline apenas | Produção nova |

### 11.2 Progressive Rollout

```
Phase 0 (Week 1-2):  off → shadow (5% leads, canary)
    │
    ├─ Infrastructure: Event Store, Projection Service, Feature Flag, Observability
    ├─ Capability Registry: Manifest, Contracts, Certification, Versioning
    └─ Shadow Mode: diff_report.json + alertas se vision_delta < -0.5
    │
Phase 1 (Week 3-4):  shadow 5% → 20%
    │
    ├─ Knowledge Core: Journal, Decision Registry, Hypothesis Registry, Confidence Engine
    ├─ Website Workflow: Capabilities hero, sections, cta, footer, seo
    └─ Certification: Mínimo 3 capabilities certified
    │
Phase 2 (Week 5-6):  shadow 20% → 50%
    │
    ├─ Evolution Engine: Pattern mining, Hypothesis validation, Auto-certification
    ├─ Rollback automation: Flag flip < 30s
    └─ Observability: Dashboards p95, error rate, vision_score distribution
    │
Phase 3 (Week 7-8):  shadow 50% → 100% (on)
    │
    ├─ Legacy codepath removal (gate: zero diffs críticos por 2 semanas)
    ├─ Documentation update
    └─ Team enablement
```

### 11.3 Rollback Criteria (Automático)

| Métrica | Threshold | Ação |
|---------|-----------|------|
| `vision_score` delta (capability - legacy) | < -0.5 por 3 runs consecutivos | Alert + pause rollout |
| Error rate (capability) | > 2x legacy | Auto-rollback to `off` |
| `diff_report` divergences críticas | > 5 por run | Alert + investigate |
| Capability latency p95 | > 2x legacy | Alert + optimize |

### 11.4 Capability Certification Gate

**Nenhuma capability vai a produção sem:**
- [ ] Manifest válido + contracts tipados
- [ ] Test coverage ≥ 85% (unit + integration + vision smoke)
- [ ] Vision score ≥ 8.0 em 10 runs shadow consecutivos
- [ ] Zero CRITICAL/HIGH security findings
- [ ] `semantic_fingerprint` estável (diff < 0.05 entre runs)
- [ ] Documentação de uso + exemplos
- [ ] Aprovação humana (checklist no PR)

---

## 12. Observability & Operations

### 12.1 Key Metrics

| Métrica | Fonte | Alerta |
|---------|-------|--------|
| `pipeline.duration_ms.p95` | Manager FSM | > 120s |
| `vision_score.distribution` | QG v2 | p50 < 7.5 |
| `knowledge_journal.events_per_lead` | Journal | < 7 (esperado 10+) |
| `pattern_library.confidence_avg` | Confidence Engine | < 0.6 |
| `hypothesis_registry.validation_rate` | Hypothesis Registry | < 30% |
| `capability.certification_rate` | Registry | < 1/month |
| `shadow.diff.vision_delta` | Diff Report | < -0.5 |

### 12.2 Structured Logging

```python
# Todos os agentes usam:
logger.info("EVENT_KEY lead_id=%s key=value ...", lead_id, key=value)
# Chaves padrão: lead_id, stage, duration_ms, vision_score, state_transition
```

### 12.3 Dashboards (Grafana)

- **Pipeline Overview**: throughput, latency, success rate por stage
- **Knowledge Health**: events/lead, hypothesis validation rate, pattern confidence
- **Quality Gate**: vision_score trend, repair rate, repair success rate
- **Capability Registry**: certified count, usage by capability, version adoption
- **Shadow Mode**: diff_report trends, divergence heatmap

---

## 13. Security & Compliance

### 13.1 Data Handling

| Dado | Classificação | Retenção | Criptografia |
|------|---------------|----------|--------------|
| Lead PII (nome, telefone, cidade) | Sensível | 2 anos | AES-256 at rest |
| Knowledge Journal events | Operacional | 5 anos | AES-256 at rest |
| Hypothesis text | Propriedade intelectual | 5 anos | AES-256 at rest |
| Pattern Library specs | IP | Permanente | AES-256 at rest |
| Vision screenshots | Temporário | 24h | — (memória) |

### 13.2 LGPD Compliance

- **Consentimento**: Capturado no lead intake (Franz consent hub)
- **Direito ao esquecimento**: `DELETE /leads/{id}` → purga Journal + Hypothesis + Patterns associados
- **Portabilidade**: `GET /leads/{id}/export` → JSON completo
- **Minimização**: Payloads contêm apenas campos necessários

### 13.3 Secrets Management

- **Zero hardcoded secrets** (regra obrigatória)
- Environment variables + secret manager (VPS: `.env` restrito root)
- Rotation: API keys (OpenRouter, 9router) a cada 90 dias

---

## 14. Definition of Done — Capability Certification

Uma capability **só é "done"** quando **TODOS** os critérios abaixo são atendidos:

### 14.1 Contract & Interface

- [ ] `manifest.yaml` válido (schema versionado)
- [ ] `contracts.py` com Input/Output Pydantic models
- [ ] Type hints completos (mypy strict passa)
- [ ] Docstring com exemplos de uso

### 14.2 Testing

- [ ] Unit tests: coverage ≥ 85% (linhas + branches)
- [ ] Integration test: pipeline end-to-end com mock LLM
- [ ] Vision smoke test: 3 runs consecutivos ≥ 8.0
- [ ] Regression test: semantic_fingerprint stability (diff < 0.05)
- [ ] Property-based tests (hypothesis) para inputs edge-case

### 14.3 Quality Gate

- [ ] Vision score ≥ 8.0 em 10 runs shadow consecutivos
- [ ] Zero CRITICAL/HIGH findings (security-reviewer agent)
- [ ] Zero MEDIUM findings não justificados
- [ ] Accessibility: axe-core zero violations

### 14.4 Observability

- [ ] Structured logs com `capability_id`, `version`, `lead_id`
- [ ] Metrics: duration_ms, vision_score, token_usage, error_rate
- [ ] Trace ID propagado através de toda a pipeline

### 14.5 Documentation

- [ ] README.md: propósito, inputs, outputs, exemplos
- [ ] Migration guide (se breaking change de versão anterior)
- [ ] ADR (Architecture Decision Record) para decisões não-óbvias

### 14.6 Operational

- [ ] Deployável independentemente (sem breaking changes em outras capabilities)
- [ ] Rollback testado (versão anterior sobe em < 30s)
- [ ] Feature flag guard: `FRALIB_AGENCY_OS=on` required
- [ ] Shadow mode validated (diff_report.json clean por 2 semanas)

### 14.7 Human Approval

- [ ] Code review aprovado (code-reviewer agent + human)
- [ ] Security review aprovado (security-reviewer agent)
- [ ] Product/Design sign-off (vision_score, UX)
- [ ] Merge para `master` com tag `capability/{id}/v{version}`

---

## 15. Apêndice: Referências de Código

| Componente | Arquivo | Linhas-chave |
|------------|---------|--------------|
| Manager FSM | `backend/agents/manager/agent.py` | `PipelineState`, `run_pipeline()`, `journal_record()` |
| Hunter | `backend/agents/hunter/agent.py` | `build_market_intelligence()` |
| Hunter Contracts | `backend/agents/hunter/contracts.py` | `HunterResult.market_intelligence` |
| Arquiteto | `backend/agents/arquiteto/agent.py` | `DesignerPRD`, `gerar_prd()` market_intel consumption |
| Quality Gate v2 | `backend/agents/builder/quality_gate_v2/__init__.py` | `run_quality_gate_v2()`, `reinforce()`, `semantic_diff` |
| Knowledge Journal | `backend/core/knowledge_journal.py` | `EVENT_TYPES`, `record()`, `stream()` |
| Confidence Engine | `backend/core/confidence.py` | `reinforce()`, `pattern_library` upsert |
| Semantic Diff | `backend/core/semantic_diff.py` | `DOMAIN_MAP`, `diff()`, `format_for_journal()` |
| Feature Flag | `backend/agents/manager/agent.py` | `FRALIB_AGENCY_OS`, shadow mode logic |

---

## 16. Changelog

| Versão | Data | Autor | Mudança |
|--------|------|-------|---------|
| 1.0 | 2026-07-21 | — | Criação inicial — Source of Truth para Knowledge-Centered OS |

---

**FIM DO DOCUMENTO**