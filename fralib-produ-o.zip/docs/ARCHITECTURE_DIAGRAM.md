# ARQUITETURA AUTÔNOMA FRA — Diagrama Completo

> **Objetivo:** Pipeline de agência digital autônoma que produz sites nível Awwwards.
> **Princípio:** 5 agentes principais + 1 objeto único evoluído + 1 guardião de coerência + 1 memória viva.

---

## 1. VISÃO GERAL — 5 Agentes + Cérebro Compartilhado

```mermaid
flowchart TB
    subgraph ENTRADA["📥 ENTRADA"]
        LEAD[("Lead Data<br/>nome, segmento, cidade,<br/>telefone, website, rating,<br/>reviews, fotos, endereço")]
    end

    subgraph NIVEL1["🔬 NÍVEL 1 — RESEARCH DIRECTOR"]
        RD[Research Director]
        RD_MODS["Módulos Internos:<br/>Business → Mercado → SEO → GEO →<br/>Concorrentes → ICP → Benchmark →<br/>Tendências → Awwwards Refs → AI Search Refs"]
    end

    subgraph NIVEL2["🎯 NÍVEL 2 — STRATEGY DIRECTOR"]
        SD[Strategy Director]
    end

    subgraph NIVEL3["🎨 NÍVEL 3 — CREATIVE DIRECTOR"]
        CD[Creative Director]
    end

    subgraph NIVEL4["🏗️ NÍVEL 4 — BUILDER"]
        BL[Builder<br/>(OpenUI + generate.js)]
    end

    subgraph NIVEL5["⚖️ NÍVEL 5 — REVIEW COUNCIL"]
        RC[Review Council<br/>10 Críticos Paralelos]
    end

    subgraph CEREBRO["🧠 CÉREBRO COMPARTILHADO"]
        PB[(ProjectBlueprint<br/>Único Objeto Evoluído)]
        CM[(Creative Memory<br/>Decisões + Racional)]
        CSO[Chief Strategy Officer<br/>Resolver Conflitos]
    end

    LEAD --> RD
    RD -->|research_report| PB
    PB --> SD
    SD -->|strategy_report| PB
    PB --> CD
    CD -->|design_constitution + blueprint| PB
    PB --> BL
    BL -->|HTML| RC
    RC -->|scores + feedback| PB
    PB -.->|loop refinamento ≤3| BL
    PB --> CSO
    CSO -.->|decisão final| PB
    RD -.->|salva decisões| CM
    SD -.->|salva decisões| CM
    CD -.->|salva decisões| CM
    BL -.->|salva decisões| CM
    RC -.->|salva decisões| CM
```

---

## 2. PROJECTBLUEPRINT — Objeto Único que Evolui

```mermaid
classDiagram
    class ProjectBlueprint {
        +Business business
        +Market market
        +Brand brand
        +Strategy strategy
        +Creative creative
        +UX ux
        +Motion motion
        +SEO seo
        +GEO geo
        +CRO cro
        +AISearch ai_search
        +Technical technical
        +Quality quality
        +Metadata metadata
    }

    class Business {
        +why_exists: str
        +transformation_delivered: str
        +problem_solved: str
        +market_position: str
        +ticket_medio: float
        +margem: float
        +diferencial_unico: str
        +objetivo_site: List[str]
        +kpi_sucesso: str
    }

    class Market {
        +dominantes: List[Competitor]
        +em_crescimento: List[Competitor]
        +em_declinio: List[Competitor]
        +padroes_mercado: List[str]
        +cliches_mercado: List[str]
        +oportunidades: List[str]
        +gaps_nao_atendidos: List[str]
        +benchmark_visual: List[VisualRef]
        +awwwards_references: List[AwwwardsRef]
    }

    class Brand {
        +quem_somos: str
        +quem_nunca_seremos: str
        +voice: VoiceProfile
        +visual: VisualProfile
        +emocoes: EmotionProfile
        +brand_dna: BrandDNA
        +teste_logo_passou: bool
    }

    class Strategy {
        +posicionamento: str
        +promessa_central: str
        +por_que_escolher: str
        +diferenciais: List[Diferencial]
        +provas: List[Prova]
        +objecoes_principais: List[Objecao]
        +como_vencer_concorrentes: str
        +percepcao_valor: str
        +narrative_arc: List[NarrativeBeat]
        +cro_plan: CROPlan
        +seo_plan: SEOPlan
        +geo_plan: GEOPlan
        +ai_search_plan: AISearchPlan
    }

    class Creative {
        +design_constitution: DesignConstitution
        +experience_blueprint: ExperienceBlueprint
        +visual_rhythm: VisualRhythm
        +wireframe: Wireframe
        +component_library: ComponentLibrary
        +motion_plan: MotionPlan
        +photography_plan: PhotographyPlan
        +typography_plan: TypographyPlan
        +layout_plan: LayoutPlan
    }

    class Technical {
        +tokens_spec: TokensSpec
        +breakpoints: List[str]
        +performance_budget: PerformanceBudget
        +accessibility_spec: AccessibilitySpec
        +browser_support: List[str]
        +cdn_strategy: CDNStrategy
        +build_pipeline: BuildPipeline
        +html_structure_rules: List[str]
    }

    class Quality {
        +vision_qa_spec: VisionQASpec
        +deterministic_gates: List[Gate]
        +critics_config: List[CriticConfig]
        +min_score: int = 95
        +max_iterations: int = 3
    }

    ProjectBlueprint *-- Business
    ProjectBlueprint *-- Market
    ProjectBlueprint *-- Brand
    ProjectBlueprint *-- Strategy
    ProjectBlueprint *-- Creative
    ProjectBlueprint *-- Technical
    ProjectBlueprint *-- Quality
```

---

## 3. CREATIVE MEMORY — Memória Viva de Decisões

```mermaid
flowchart LR
    subgraph AGENTES["Agentes que Escrevem"]
        RD[Research Director]
        SD[Strategy Director]
        CD[Creative Director]
        BL[Builder]
        RC[Review Council]
    end

    subgraph MEMORY["🧠 CREATIVE MEMORY (Append-Only Log)"]
        LOG[(JSONL Log<br/>timestamp, agent, decision, rationale, alternatives_rejected, confidence)]
    end

    RD -->|decide: archetype| LOG
    SD -->|decide: positioning| LOG
    CD -->|decide: typography, palette, rhythm| LOG
    BL -->|decide: component implementation| LOG
    RC -->|decide: score, rejection reason| LOG

    LOG -.->|query: "por que serif?"| RD
    LOG -.->|query: "por que preto?"| SD
    LOG -.->|query: "por que ritmo lento?"| CD
    LOG -.->|query: "por que componente X?"| BL
    LOG -.->|auditoria completa| CSO[CSO]
```

**Formato de Entrada no Log:**
```json
{
  "timestamp": "2026-07-20T14:32:00Z",
  "agent": "Creative Director",
  "decision": "Typography: Fraunces display + Inter body",
  "rationale": "Editorial-asymmetric archetype demands serif headline for authority + humanist sans for readability. Fraunces has variable opsz enabling 18vw hero without optical breakage.",
  "alternatives_rejected": [
    {"option": "Playfair Display", "reason": "Too classical, lacks modern edge"},
    {"option": "Anton", "reason": "Industrial-bold only, breaks editorial warmth"}
  ],
  "confidence": 0.94,
  "constitution_ref": "Creative.typography_plan.display_font"
}
```

---

## 4. CHIEF STRATEGY OFFICER — Guardião da Coerência

```mermaid
flowchart TD
    CONFLICT["⚡ CONFLITO DETECTADO"] --> CSO
    
    subgraph CSO_LOGIC["CSO Decision Engine"]
        CSO[Chief Strategy Officer]
        RULES["Regras de Prioridade:\n1. Brand DNA > Preferência Pessoal\n2. Strategy > Creative whim\n3. SEO/GEO intent > Visual trend\n4. CRO > Aesthetic purity\n5. Technical feasibility > Ambição impossível\n6. ICP validation > Internal ego"]
        MEMORY[Creative Memory<br/>Histórico de decisões]
        BLUEPRINT[ProjectBlueprint<br/>Estado atual]
    end

    CSO -->|query| RULES
    CSO -->|query| MEMORY
    CSO -->|query| BLUEPRINT
    
    CSO --> DECISION{Decisão}
    DECISION -->|Aceita| APPLY["Aplica no Blueprint\n+ Log no Creative Memory"]
    DECISION -->|Rejeita| REJECT["Rejeita + Rationale\n+ Sugere Alternativa"]
    DECISION -->|Compromisso| COMPROMISE["Meio-termo Documentado\n+ Trade-off Explícito"]
```

**Exemplo Real:**
```
Input Research: "Mercado saturado, competem por preço"
Input Brand: "Queremos parecer premium, exclusivo"
Input SEO: "Buscas são 'academia barata [cidade]'"
Input Creative: "Quero fundo preto minimalista, tipografia gigante"

CSO Decision:
"Ignorar guerra por preço. Construir autoridade via conteúdo.
Posicionamento: 'Premium acessível' — qualidade de elite, preço justo.
SEO foca intenção de qualidade ('melhor academia', 'treino personalizado').
Visual permanece premium (preto + gold), mas hero mostra pessoas reais treinando."
```

---

## 5. REVIEW COUNCIL — 10 Críticos + Loop de Refinamento

```mermaid
flowchart TB
    HTML[("HTML Gerado\npelo Builder")] --> RC[Review Council]
    
    subgraph CRITICS["10 Críticos Paralelos (async)"]
        C1[Creative Director<br/>Design, Originalidade, Memorabilidade]
        C2[UX Lead<br/>Fluxo, Usabilidade, Escaneabilidade]
        C3[CRO Specialist<br/>Conversão, CTA, Objeções]
        C4[SEO Lead<br/>SEO, Arquitetura, Cluster]
        C5[GEO Lead<br/>IA, Perguntas, Contexto]
        C6[Motion Designer<br/>Ritmo, Animações, Microinterações]
        C7[Brand Director<br/>Consistência, DNA, Personalidade]
        C8[Art Director<br/>Fotografia, Grid, Tipografia, Composição]
        C9[Frontend Lead<br/>Performance, Código, Acessibilidade]
        C10[ICP (Cliente Ideal)<br/>Compraria?, Confiou?, Entendeu?, Confuso?, Vale o preço?]
    end
    
    RC --> C1 & C2 & C3 & C4 & C5 & C6 & C7 & C8 & C9 & C10
    
    C1 & C2 & C3 & C4 & C5 & C6 & C7 & C8 & C9 & C10 --> AGG[Aggregator]
    
    AGG --> CHECK{All ≥ 95?}
    CHECK -->|SIM| PASS[✅ APROVADO\n→ Deploy]
    CHECK -->|NÃO| FEEDBACK[Aggregated Feedback\npor Crítico que Falhou]
    
    FEEDBACK --> ITER{Iteration < 3?}
    ITER -->|SIM| REFINE[Master Prompt\nGera Instruções de Correção]
    REFINE --> BL[Builder\nRegenera HTML]
    BL --> RC
    ITER -->|NÃO (3 falhas)| ESCALATE[⚠️ ESCALA PARA CSO\nDecisão Humana Necessária]
```

**Output do Review Council:**
```json
{
  "review_result": {
    "scores": {
      "creative_director": 97,
      "ux_lead": 94,
      "cro_specialist": 96,
      "seo_lead": 98,
      "geo_lead": 93,
      "motion_designer": 91,
      "brand_director": 99,
      "art_director": 95,
      "frontend_lead": 97,
      "icp": 92
    },
    "min_score": 91,
    "all_passed": false,
    "failed_critics": ["ux_lead", "geo_lead", "motion_designer", "icp"],
    "blocking_issues": [
      "UX: Scroll rhythm quebrado na seção 3 (gap excessivo)",
      "GEO: FAQ não cobre 'quanto custa personal trainer'",
      "Motion: Parallax intensity 0.30 causa motion sickness em mobile",
      "ICP: 'Não entendi se inclui nutricionista'"
    ],
    "refinement_instructions": [
      "Fix section 3 spacing to match visual_rhythm.breathing_points[1]",
      "Add FAQ entry for pricing transparency per GEO plan",
      "Reduce parallax_intensity to 0.15 on mobile per motion_plan.mobile_constraints",
      "Add 'Nutricionista incluso no plano Premium' to CRO conversion_architecture[2]"
    ],
    "iteration": 1,
    "max_iterations": 3
  }
}
```

---

## 6. MAPEAMENTO: Agentes Existentes → Nova Arquitetura

```mermaid
flowchart LR
    subgraph EXISTENTES["📦 Agentes Atuais (6)"]
        H[Hunter\nLead Mining]
        C[Caio\nQualificação]
        A[Arquiteto\nDesignerPRD]
        B[Builder\nOpenUI Proxy]
        QG[Quality Gate\nVision QA v2]
        F[Franz\nSDR WhatsApp]
        M[Manager\nFSM Orchestrator]
    end

    subgraph NOVA["🏗️ Nova Arquitetura (5 + Cérebro)"]
        RD[Research Director]
        SD[Strategy Director]
        CD[Creative Director]
        BL[Builder]
        RC[Review Council]
        PB[(ProjectBlueprint)]
        CM[(Creative Memory)]
        CSO[CSO]
    end

    H -->|lead_data + market_intel| RD
    C -->|tier + score + paleta| RD
    C -->|qualificação| SD
    A -->|SYSTEM_PROMPT + design_tokens| CD
    A -->|layout_dna + design_system| CD
    B -->|render_site| BL
    QG -->|vision_qa_spec| RC
    QG -->|repair_loop| BL
    F -->|fora do pipeline| F2[Franz\n(Pós-Deploy)]
    M -->|FSM expandido| ORCH[Orchestrator\n(Novo Manager)]
    
    style RD fill:#e1f5fe
    style SD fill:#fff3e0
    style CD fill:#fce4ec
    style BL fill:#e8f5e9
    style RC fill:#f3e5f5
```

**Detalhamento do Mapeamento:**

| Agente Atual | Vai Para | O Que Migra | O Que Fica (Legado) |
|-------------|----------|-------------|---------------------|
| **Hunter** | Research Director (módulo Business + Mercado) | `search()`, providers, cache, `_market_intelligence()` | — |
| **Caio** | Research Director (módulo Business) + Strategy Director (input) | `qualificar()`, scoring, tier, paleta_segmento | shims compat |
| **Arquiteto** | **DIVIDIDO**: Research (SEO/GEO) + Strategy (Brand/Positioning) + Creative (Design Constitution) | `gerar_prd()`, DESIGN_LESSONS, theme_mapper integration, entity_tags, layout_constraints | SYSTEM_PROMPT_BASE vira Creative Director prompt |
| **Builder** | Builder (OpenUI Proxy) | `render_site()`, `_prd_to_dict()`, `_inject_system_extras()` | — |
| **Quality Gate** | Review Council (Vision QA = 1 de 10 critics) + Quality (gates determinísticos) | Vision QA v2, repair_loop, thresholds | — |
| **Franz** | **FORA DO PIPELINE** (pós-deploy SDR) | Mantém 100% — memory, learning, audio, 30 axes, LGPD | — |
| **Manager** | **REWRITE** → Orchestrator (FSM 5 estados + loop) | Estado persistence, job queue | FSM antiga |

---

## 7. FSM DO ORCHESTRATOR (Novo Manager)

```mermaid
stateDiagram-v2
    [*] --> INIT
    INIT --> RESEARCH: lead_data
    
    state RESEARCH {
        [*] --> BUSINESS_MODULE
        BUSINESS_MODULE --> MERCADO_MODULE
        MERCADO_MODULE --> SEO_MODULE
        SEO_MODULE --> GEO_MODULE
        GEO_MODULE --> CONCORRENTES_MODULE
        CONCORRENTES_MODULE --> ICP_MODULE
        ICP_MODULE --> BENCHMARK_MODULE
        BENCHMARK_MODULE --> TENDENCIAS_MODULE
        TENDENCIAS_MODULE --> AWWWARDS_MODULE
        AWWWARDS_MODULE --> AI_SEARCH_MODULE
        AI_SEARCH_MODULE --> [*]
    }
    
    RESEARCH --> STRATEGY: research_report completo
    
    state STRATEGY {
        [*] --> BRAND_DNA
        BRAND_DNA --> MANIFESTO
        MANIFESTO --> POSICIONAMENTO
        POSICIONAMENTO --> PROMESSA
        PROMESSA --> DIFERENCIAIS
        DIFERENCIAIS --> ARQUETIPOS
        ARQUETIPOS --> EMOTIONAL_BLUEPRINT
        EMOTIONAL_BLUEPRINT --> NARRATIVA
        NARRATIVA --> CRO_PLAN
        CRO_PLAN --> SEO_PLAN
        SEO_PLAN --> GEO_PLAN
        GEO_PLAN --> AI_SEARCH_PLAN
        AI_SEARCH_PLAN --> [*]
    }
    
    STRATEGY --> CREATIVE: strategy_report completo
    
    state CREATIVE {
        [*] --> DESIGN_CONSTITUTION
        DESIGN_CONSTITUTION --> EXPERIENCE_BLUEPRINT
        EXPERIENCE_BLUEPRINT --> VISUAL_RHYTHM
        VISUAL_RHYTHM --> WIREFRAME
        WIREFRAME --> COMPONENT_LIBRARY
        COMPONENT_LIBRARY --> MOTION_PLAN
        MOTION_PLAN --> PHOTOGRAPHY_PLAN
        PHOTOGRAPHY_PLAN --> TYPOGRAPHY_PLAN
        TYPOGRAPHY_PLAN --> LAYOUT_PLAN
        LAYOUT_PLAN --> [*]
    }
    
    CREATIVE --> BUILD: design_constitution + blueprint
    
    state BUILD {
        [*] --> GENERATE_HTML
        GENERATE_HTML --> INJECT_SYSTEM
        INJECT_SYSTEM --> VALIDATE_HTML
        VALIDATE_HTML --> [*]
    }
    
    BUILD --> REVIEW: HTML gerado
    
    state REVIEW {
        [*] --> PARALLEL_CRITICS
        PARALLEL_CRITICS --> AGGREGATE
        AGGREGATE --> CHECK_SCORES
        CHECK_SCORES --> PASS: all >= 95
        CHECK_SCORES --> REFINE: any < 95 && iter < 3
        CHECK_SCORES --> ESCALATE_CSO: any < 95 && iter >= 3
        REFINE --> MASTER_PROMPT
        MASTER_PROMPT --> BUILD: regenera
    }
    
    REVIEW --> DEPLOY: PASS
    DEPLOY --> OUTREACH: site publicado
    OUTREACH --> [*]: Franz assume
    
    ESCALATE_CSO --> CSO_DECISION
    CSO_DECISION --> BUILD: força aprovação com rationale
    CSO_DECISION --> [*]: abort
```

---

## 8. ESTRUTURA DE PASTAS PROPOSTA

```
backend/agents/
├── research_director/
│   ├── agent.py              # Orquestra 10 módulos internos
│   ├── modules/
│   │   ├── business.py       # Business (ex-Caio + Hunter lead_data)
│   │   ├── mercado.py        # Mercado (ex-Hunter _market_intelligence)
│   │   ├── seo.py            # SEO Clusters + Keywords
│   │   ├── geo.py            # GEO Entities + Bairros + Referências
│   │   ├── concorrentes.py   # Competitive Analysis
│   │   ├── icp.py            # Ideal Customer Profile
│   │   ├── benchmark.py      # Visual + Functional Benchmark
│   │   ├── tendencias.py     # Trends 2026
│   │   ├── awwwards_refs.py  # Awwwards Winners Analysis
│   │   └── ai_search_refs.py # AI Search Patterns
│   ├── contracts.py          # ResearchReport (Pydantic)
│   └── prompts.py
│
├── strategy_director/
│   ├── agent.py
│   ├── modules/
│   │   ├── brand_dna.py
│   │   ├── manifesto.py
│   │   ├── positioning.py
│   │   ├── promise.py
│   │   ├── differentiators.py
│   │   ├── archetypes.py
│   │   ├── emotional_blueprint.py
│   │   ├── narrative.py
│   │   ├── cro_plan.py
│   │   ├── seo_plan.py
│   │   ├── geo_plan.py
│   │   └── ai_search_plan.py
│   ├── contracts.py          # StrategyReport (Pydantic)
│   └── prompts.py
│
├── creative_director/
│   ├── agent.py
│   ├── modules/
│   │   ├── design_constitution.py    # 17 Regras Design Constitution v2.0
│   │   ├── experience_blueprint.py
│   │   ├── visual_rhythm.py
│   │   ├── wireframe.py
│   │   ├── component_library.py
│   │   ├── motion_plan.py
│   │   ├── photography_plan.py
│   │   ├── typography_plan.py
│   │   └── layout_plan.py
│   ├── contracts.py          # CreativeBlueprint (Pydantic)
│   └── prompts.py
│
├── builder/
│   ├── agent.py              # OpenUI Proxy (existente, adaptado)
│   ├── contracts.py
│   └── prompts.py
│
├── review_council/
│   ├── agent.py              # Orquestra 10 critics paralelos
│   ├── critics/
│   │   ├── creative_director.py
│   │   ├── ux_lead.py
│   │   ├── cro_specialist.py
│   │   ├── seo_lead.py
│   │   ├── geo_lead.py
│   │   ├── motion_designer.py
│   │   ├── brand_director.py
│   │   ├── art_director.py
│   │   ├── frontend_lead.py
│   │   └── icp.py
│   ├── contracts.py          # ReviewResult (Pydantic)
│   └── prompts.py
│
├── master_prompt/
│   ├── agent.py              # Gera prompt final p/ Builder
│   ├── contracts.py
│   └── prompts.py
│
├── orchestrator/             # NOVO Manager
│   ├── agent.py              # FSM 5 estados + loop review
│   ├── state.py              # PipelineState com ProjectBlueprint
│   └── persistence.py        # Salva/carrega Blueprint por lead_id
│
├── cso/
│   ├── agent.py              # Resolve conflitos estratégicos
│   ├── rules.py              # Prioridades codificadas
│   └── contracts.py
│
├── creative_memory/
│   ├── agent.py              # Append-only log + query
│   ├── storage.py            # JSONL + SQLite FTS
│   └── contracts.py
│
├── franz/                    # INALTERADO (pós-deploy)
│   ├── agent.py
│   ├── memory.py
│   ├── learning.py
│   ├── audio.py
│   ├── playbook.json
│   └── contracts.py
│
└── _shared/
    ├── project_blueprint.py  # Dataclass/Pydantic raiz
    ├── constants.py
    └── llm_client.py         # Wrapper unificado
```

---

## 9. FLUXO DE DADOS COMPLETO

```mermaid
sequenceDiagram
    participant Lead as Lead Input
    participant RD as Research Director
    participant PB as ProjectBlueprint
    participant SD as Strategy Director
    participant CD as Creative Director
    participant BL as Builder
    participant RC as Review Council
    participant CSO as CSO
    participant CM as Creative Memory
    participant Deploy as Deploy + Franz

    Lead->>RD: lead_data (nome, segmento, cidade, telefone, rating, reviews, fotos, website)
    RD->>RD: Executa 10 módulos paralelos (business, mercado, seo, geo, concorrentes, icp, benchmark, tendencias, awwwards, ai_search)
    RD->>PB: research_report (preenche Business + Market)
    RD->>CM: Log decisions (archetype signals, market gaps, keyword clusters)
    
    PB->>SD: research_report
    SD->>SD: Sintetiza 12 módulos (brand_dna, manifesto, positioning, promise, differentiators, archetypes, emotional_blueprint, narrative, cro, seo, geo, ai_search)
    SD->>PB: strategy_report (preenche Brand + Strategy)
    SD->>CM: Log decisions (positioning rationale, promise wording, differentiator proof)
    
    PB->>CD: strategy_report
    CD->>CD: Gera 10 módulos criativos (design_constitution 17 regras, experience, rhythm, wireframe, components, motion, photography, typography, layout)
    CD->>PB: creative_blueprint (preenche Creative)
    CD->>CM: Log decisions (font choice, palette rationale, rhythm beats, motion choreography)
    
    PB->>BL: creative_blueprint + design_tokens + layout_dna
    BL->>BL: OpenUI generate.js + inject.py + motion.py
    BL->>RC: HTML final
    
    RC->>RC: 10 critics paralelos avaliam HTML vs 8 constituições
    RC->>PB: review_result (scores, issues, refinement_instructions)
    RC->>CM: Log scores + rejection reasons
    
    alt All scores ≥ 95
        PB->>Deploy: APROVADO → Deploy
        Deploy->>Franz: Lead qualificado + site URL
    else Any score < 95
        PB->>CSO: Conflito (se iter ≥ 3 ou deadlock)
        CSO->>PB: Decisão final + rationale
        CSO->>CM: Log CSO decision
        PB->>BL: Master Prompt com refinement_instructions
        BL->>RC: HTML regenerado (loop max 3)
    end
```

---

## 10. REGRAS DE OURO DA NOVA ARQUITETURA

| Regra | Descrição |
|-------|-----------|
| **Único Blueprint** | Um `ProjectBlueprint` mutável (append-only por seção) passa por todos os agentes. Nunca múltiplos JSONs. |
| **Creative Memory Obrigatório** | Toda decisão estratégica/criativa é logada com rationale. Builder consulta antes de implementar. |
| **CSO Decide Conflitos** | Research vs Brand vs SEO vs Creative → CSO resolve com regras explícitas + memória. |
| **Review Council = Gate Real** | 10 critics paralelos. Score < 95 = loop automático (máx 3). Após 3 falhas → CSO humano. |
| **Builder é Puro Executor** | Recebe Master Prompt completo. Zero decisão criativa. Só implementa. |
| **Franz Fora do Pipeline** | SDR só entra pós-deploy. Não bloqueia geração. |
| **Módulos Internos = Testáveis** | Cada módulo do Research/Strategy/Creative é função pura: input → output. Testável isoladamente. |
| **Validação Determinística Primeiro** | Antes de LLM: valida schema, constraints, gates. LLM só para síntese/criação. |
| **Theme Mapper = Fonte da Verdade Visual** | `derive_design_tokens()` é determinístico. Archetype + Paleta única por hash. Zero clone. |
| **Rastelo + Massa Corporal = Inject.py** | Anti-hallucination enforcement + authority blocks. Mantém fora do LLM. |

---

## 11. PRÓXIMOS PASSOS (Plano de Implementação)

### Fase 0: Fundação (1 dia)
- [ ] Criar `backend/agents/_shared/project_blueprint.py` (dataclass raiz)
- [ ] Criar `backend/agents/_shared/creative_memory.py` (append-only log + query)
- [ ] Criar `backend/agents/_shared/cso.py` (regras + decision engine)
- [ ] Estender `theme_mapper.py` se necessário (já tem 90%)

### Fase 1: Research Director (2 dias)
- [ ] Estrutura `research_director/` + 10 módulos internos
- [ ] Migrar `Hunter._market_intelligence()` → `modules/mercado.py`
- [ ] Migrar `Caio.qualificar()` → `modules/business.py`
- [ ] Implementar SEO, GEO, Concorrentes, ICP, Benchmark, Tendências, Awwwards, AI Search
- [ ] `contracts.py`: `ResearchReport` (Pydantic)
- [ ] Testes: `tests/agents/test_research_director.py`

### Fase 2: Strategy Director (2 dias)
- [ ] Estrutura `strategy_director/` + 12 módulos
- [ ] Brand DNA + "Teste do Logo" (heurística de unicidade)
- [ ] Manifesto, Positioning, Promise, Differentiators, Archetypes
- [ ] Emotional Blueprint, Narrative Arc (10 beats)
- [ ] CRO/SEO/GEO/AI Search Plans
- [ ] `contracts.py`: `StrategyReport`
- [ ] Testes

### Fase 3: Creative Director (3 dias) — **CORE**
- [ ] Estrutura `creative_director/` + 10 módulos
- [ ] **Design Constitution v2.0**: 17 regras como validações determinísticas
- [ ] Experience Blueprint (journey map 8 estágios)
- [ ] Visual Rhythm (breathing points, surprise moments)
- [ ] Wireframe + Component Library (spec, não código)
- [ ] Motion Plan (parallax, reveal, stagger, mobile constraints)
- [ ] Photography Plan (real > stock, treatment consistente)
- [ ] Typography Plan (display + body + mono, scale, tracking, weight)
- [ ] Layout Plan (section types variados, zero cards-cards-cards)
- [ ] `contracts.py`: `CreativeBlueprint`
- [ ] Testes

### Fase 4: Builder + Review Council (2 dias)
- [ ] Adaptar `builder/agent.py` para receber `CreativeBlueprint` + `MasterPrompt`
- [ ] `review_council/` com 10 critics paralelos
- [ ] Vision QA v2 integrado como 1 critic (não gate isolado)
- [ ] Aggregator + loop refinamento (max 3)
- [ ] `master_prompt/agent.py` gera prompt final

### Fase 5: Orchestrator + Integração (1.5 dias)
- [ ] `orchestrator/agent.py` — FSM 5 estados + loop review
- [ ] Persistência `ProjectBlueprint` por `lead_id` (JSONB em `leads.constitutions`)
- [ ] Integração ponta-a-ponta: `python pipeline.py smoke --lead nutri-ca-sample`

### Fase 6: Testes + Deploy (0.5 dia)
- [ ] E2E tests
- [ ] Smoke VPS
- [ ] Documentação

**Total estimado: ~12 dias de implementação focada**

---

## 12. DECISÕES PENDENTES (Para Aprovação)

1. **LLM para módulos internos?** Research/Strategy/Creative modules usam LLM ou são heurísticos determinísticos? (Recomendo: híbrido — heurística para extração, LLM para síntese)
2. **CSO humano ou automático?** Iniciar com regras codificadas; escalar para humano após 3 falhas.
3. **Creative Memory storage:** JSONL arquivo local vs SQLite FTS vs PostgreSQL? (Recomendo SQLite FTS para query semântica)
4. **Review Council critics prompts:** Cada critic tem prompt próprio ou config compartilhada? (Recomendo: prompt base compartilhado + criteria específico por critic)
5. **Franz integration:** Manter 100% separado ou hook no `OUTREACH` state para disparar primeira mensagem? (Recomendo: hook no orchestrator)

---

**Aprovação necessária para iniciar Fase 0.**