// fralibCheckout() — ponto de entrada unico para checkout Cakto.
// Chamado por onclick nos botoes de plano em planos.html.
// Fluxo: trial → redirect signup; pago → modal email → /criar-checkout-anonimo → Cakto.
(function () {
  'use strict';

  const API = '/api/credits/criar-checkout-anonimo';
  const MODAL_ID = 'fralib-checkout-modal';

  function openModal(plano) {
    let modal = document.getElementById(MODAL_ID);
    if (!modal) {
      modal = document.createElement('div');
      modal.id = MODAL_ID;
      modal.innerHTML = buildModalHTML();
      document.body.appendChild(modal);
    }
    modal.querySelector('#fc-plano').value = plano;
    modal.querySelector('#fc-email').value = '';
    modal.querySelector('#fc-error').textContent = '';
    modal.querySelector('#fc-error').style.display = 'none';
    modal.style.display = 'flex';
    setTimeout(() => modal.querySelector('#fc-email').focus(), 100);
  }

  function closeModal() {
    const m = document.getElementById(MODAL_ID);
    if (m) m.style.display = 'none';
  }

  async function submitCheckout(plano, email) {
    const btn = document.getElementById('fc-submit');
    const err = document.getElementById('fc-error');
    btn.disabled = true;
    btn.textContent = 'REDIRECIONANDO...';
    err.style.display = 'none';

    try {
      const r = await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ plano, email }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.detail || 'Erro ao iniciar checkout');

      // Cakto checkout_url OU redirect para sucesso
      if (data.checkout_url) {
        window.location.href = data.checkout_url;
      } else if (data.redirect) {
        window.location.href = data.redirect;
      } else {
        throw new Error('Checkout nao retornou URL de redirecionamento');
      }
    } catch (e) {
      err.textContent = e.message || 'Erro. Tente novamente.';
      err.style.display = 'block';
      btn.disabled = false;
      btn.textContent = 'CONTINUAR';
    }
  }

  function buildModalHTML() {
    return `<div style="position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.75);backdrop-filter:blur(4px)" onclick="if(event.target===this)fralibCheckout.close()">
  <div style="background:#12121a;border:1px solid rgba(147,51,234,0.3);border-radius:14px;padding:32px;max-width:420px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,0.5)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
      <h3 style="font-family:var(--fl-font-brand,monospace);font-size:12px;color:#c084fc;letter-spacing:1px">INICIAR ASSINATURA</h3>
      <button onclick="fralibCheckout.close()" style="background:none;border:none;color:#8888a0;font-size:20px;cursor:pointer;padding:0;line-height:1">&times;</button>
    </div>
    <p style="color:#8888a0;font-size:13px;margin-bottom:20px;line-height:1.5">Informe seu e-mail para receber o link de pagamento seguro via Cakto.</p>
    <input type="hidden" id="fc-plano">
    <div style="margin-bottom:14px">
      <label style="display:block;font-size:11px;color:#7D7890;margin-bottom:6px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px">E-mail</label>
      <input type="email" id="fc-email" placeholder="voce@exemplo.com" autocomplete="email" style="width:100%;background:#0a0714;border:1px solid #7D7890;color:#fff;padding:12px 14px;border-radius:8px;font-size:14px;font-family:inherit;outline:none" onfocus="this.style.borderColor='#9333ea'" onblur="this.style.borderColor='#7D7890'">
    </div>
    <div id="fc-error" style="display:none;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:8px;padding:10px;margin-bottom:14px;font-size:13px;color:#ef4444"></div>
    <button id="fc-submit" onclick="fralibCheckout.go()" style="width:100%;padding:14px;background:#FACC15;color:#000;font-weight:800;font-size:13px;letter-spacing:1px;border:none;border-radius:8px;cursor:pointer;transition:opacity 0.15s" onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">CONTINUAR</button>
    <p style="text-align:center;font-size:11px;color:#44445a;margin-top:14px">Pagamento seguro via Cakto. PIX e cartao.</p>
  </div>
</div>`;
  }

  // Teclado: ESC fecha modal, Enter submete
  document.addEventListener('keydown', function (e) {
    const m = document.getElementById(MODAL_ID);
    if (!m || m.style.display === 'none') return;
    if (e.key === 'Escape') { closeModal(); e.preventDefault(); }
    if (e.key === 'Enter') {
      const plano = document.getElementById('fc-plano')?.value || '';
      const email = document.getElementById('fc-email')?.value.trim() || '';
      if (plano && email) submitCheckout(plano, email);
    }
  });

  window.fralibCheckout = {
    open: openModal,
    close: closeModal,
    go: function () {
      const plano = document.getElementById('fc-plano')?.value;
      const email = document.getElementById('fc-email')?.value.trim();
      if (!plano) return;
      if (!email || !email.includes('@')) {
        const err = document.getElementById('fc-error');
        err.textContent = 'Informe um e-mail valido.';
        err.style.display = 'block';
        return;
      }
      submitCheckout(plano, email);
    },
  };
})();
